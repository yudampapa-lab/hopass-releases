﻿param([string]$ParkingRoot = 'C:\ProgramData\HodiParkingServer')
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath (Join-Path $ParkingRoot 'data\sk-credentials.dat'))) {
    $ParkingRoot = Read-Host 'HODIPARKING 설치 폴더 (data\sk-credentials.dat가 있는 폴더)'
}
$ParkingRoot = (Resolve-Path -LiteralPath $ParkingRoot).Path
$node = Join-Path $ParkingRoot 'runtime\node.exe'
if (-not (Test-Path -LiteralPath $node)) { throw 'HODIPARKING runtime\node.exe를 찾을 수 없습니다.' }
& $node -e 'if(Number(process.versions.node.split(".")[0])<20)process.exit(1)'
if ($LASTEXITCODE -ne 0) { throw 'Node.js 20 이상이 필요합니다. HODIPARKING을 업데이트해 주세요.' }
$destination = Join-Path $env:LOCALAPPDATA 'HODIPASSParkingConnector'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
foreach ($name in @('ParkingBridge.mjs','parking-policy.mjs','Start.ps1')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $destination $name) -Force
}
$code = Read-Host 'HOPASS 관리자 사이트에서 발급한 주차 연결 코드 (10분 유효)'
& $node (Join-Path $destination 'ParkingBridge.mjs') --pair $code --parking-root $ParkingRoot
if ($LASTEXITCODE -ne 0) { throw '연결하지 못했습니다. 코드와 HODIPARKING 로그인 설정을 확인해 주세요.' }
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'HODI PASS Parking.lnk'))
$shortcut.TargetPath = (Get-Command powershell.exe).Source
$shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $destination 'Start.ps1') + '"'
$shortcut.WorkingDirectory = $destination
$shortcut.WindowStyle = 7
$shortcut.Save()
Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"' + (Join-Path $destination 'Start.ps1') + '"')) -WindowStyle Hidden
Write-Host '주차 연결 프로그램을 시작했습니다. 관리자 사이트에서 연결됨 표시를 확인해 주세요.'

import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {vehicleResults,visitorPayload,discountPayload} from './parking-policy.mjs';
const RELAY='https://hopass-relay.yudampapa.workers.dev',SK='http://192.168.10.150:9080';
const here=path.dirname(fileURLToPath(import.meta.url));
function powershell(script,input=''){
 return new Promise((resolve,reject)=>{const p=spawn('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from('[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);'+script,'utf16le').toString('base64')],{windowsHide:true});let out='';p.stdout.on('data',d=>out+=d);p.stderr.resume();p.on('error',reject);p.on('close',c=>c===0?resolve(out.trim()):reject(Error('Windows 보안 설정을 읽지 못했습니다')));p.stdin.end(input);});
}
const quote=s=>"'"+String(s).replace(/'/g,"''")+"'";
async function secure(value,protect){return powershell(protect?'$s=[Console]::In.ReadToEnd()|ConvertTo-SecureString -AsPlainText -Force;ConvertFrom-SecureString $s':"$s=([Console]::In.ReadToEnd()).Trim().TrimStart([char]0xFEFF)|ConvertTo-SecureString;$p=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s);try{[Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)}",value);}
async function save(file,data){await fs.mkdir(path.dirname(file),{recursive:true});const tmp=file+'.'+randomUUID()+'.tmp';await fs.writeFile(tmp,JSON.stringify(data));await fs.rename(tmp,file);}
export function createParkingExecutor({sk,photo,authorize=async()=>{}}){
 let company=null;
 async function corpSn(){
  if(company)return company;
  const response=await sk('/api/v1/corps?sn=&corpName=&corpId=&tel=&delYn=');
  const found=response.data?.find(c=>c.corpId==='hodi_00001'&&c.delYn!=='Y');
  if(!found||!Number.isInteger(Number(found.sn))||Number(found.sn)<=0)throw Error('hodi_00001 할인권 계정을 확인해 주세요');
  return company=Number(found.sn);
 }
 async function mutate(endpoint,data,job){await authorize(job.id);if(job.expiresAt<=Date.now())throw Error('parking_request_expired');try{return await sk(endpoint,'POST',{data});}catch(e){e.uncertain=true;throw e;}}
 return async function execute(job){
  if(job.expiresAt<=Date.now())throw Error('parking_request_expired');
  if(job.action==='register'){const data=visitorPayload(job),corp=await corpSn();data.forEach(v=>v.corpSn=corp);if(job.expiresAt<=Date.now())throw Error('parking_request_expired');await mutate('/api/v1/tickets/visitors',data,job);return {registered:true,vehicleNo:job.vehicleNo,account:'hodi_00001'};}
  if(job.action==='search'){
   const response=await sk('/api/v1/dashboard/parking/discount/search/vehicle','POST',{data:{vehicleNo:String(job.vehicleNo||'')}});
   if(!Array.isArray(response.data))throw Error('차량 조회 응답을 확인해 주세요');return vehicleResults(response.data,job.vehicleNo,Date.now(),job.offset||0);
  }
  if(!/^\d{1,12}$/.test(String(job.inSn)))throw Error('차량 입차 정보를 확인해 주세요');
  if(job.action==='photo'){
   const response=await sk('/api/v1/dashboard/parking/discount/search/vehicle','POST',{data:{vehicleNo:String(job.vehicleNo||'')}});
   const vehicle=response.data?.find(v=>String(v.sn)===String(job.inSn));if(!vehicle?.imImagePath)return {photo:null};
   return {photo:await photo(vehicle.imImagePath)};
  }
  const corp=await corpSn(),allowed=await sk('/api/v1/corps/'+corp+'/'+job.inSn+'/able/ticket');
  if(!Array.isArray(allowed.data))throw Error('할인권 응답을 확인해 주세요');
  if(job.action==='tickets')return {items:allowed.data.map(t=>({classSn:String(t.corpTicketClass.sn),title:String(t.corpTicketClass.name),remaining:Math.max(0,Math.min(Number(t.ableCnt)||0,Number(t.totalCnt)||0))}))};
  if(job.action!=='apply')throw Error('지원하지 않는 작업입니다');
  const data=discountPayload(job,allowed.data);data.forEach(v=>v.corpSn=corp);
  // Check freshness again immediately before the external side effect.
  if(job.expiresAt<=Date.now())throw Error('parking_request_expired');
  await mutate('/api/v1/dashboard/parking/discount/add/ticket',data,job);
  return {applied:true,count:data.reduce((n,t)=>n+t.cnt,0),account:'hodi_00001'};
 };
}
async function main(){
 const args=process.argv.slice(2),option=k=>{const i=args.indexOf(k);return i<0?'':args[i+1]||'';};
 const configFile=path.join(here,'data','config.json');
 if(option('--pair')){
  const root=path.resolve(option('--parking-root'));await fs.access(path.join(root,'data','sk-credentials.dat'));
  const response=await fetch(RELAY+'/v1/parking/pair',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({code:option('--pair')}),signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw Error('연결 코드가 만료되었거나 올바르지 않습니다');const value=await response.json();
  await save(configFile,{parkingRoot:root,token:await secure(value.token,true)});console.log('HODI PASS 주차 연결을 저장했습니다.');return;
 }
 const config=JSON.parse(await fs.readFile(configFile,'utf8')),token=await secure(config.token,false),credential=path.join(config.parkingRoot,'data','sk-credentials.dat');
 let session='',sessionUntil=0,cookie='';
 async function sk(endpoint,method='GET',body){
  if(!session||sessionUntil<Date.now()){
   const password=await secure(await fs.readFile(credential,'utf8'),false);
   const r=await fetch(SK+'/api/v1/login/admin',{method:'POST',headers:{'content-type':'application/json',Origin:SK,Referer:SK+'/'},body:JSON.stringify({id:'admin',password}),signal:AbortSignal.timeout(8000)});
   if(!r.ok)throw Error('SK쉴더스 로그인 연결을 확인해 주세요');const login=await r.json();session=login.data?.token||login.token;if(!session)throw Error('SK쉴더스 인증 실패');sessionUntil=Date.now()+150000;cookie=r.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ');
  }
  const r=await fetch(SK+endpoint,{method,redirect:'error',headers:{authorization:'Bearer '+session,'content-type':'application/json',Origin:SK,Referer:SK+'/',...(cookie?{Cookie:cookie}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(12000)});
  if(!r.ok){if(r.status===401){session='';sessionUntil=0;}throw Error('SK쉴더스 응답 오류 ('+r.status+')');}
  const data=await r.json();if(data.msg&&data.msg!=='success')throw Error('SK쉴더스 처리 결과를 확인해 주세요');return data;
 }
 async function photo(imagePath){
  const url=new URL(imagePath,SK);if(url.origin!==SK||!url.pathname.startsWith('/park/save/')||url.username||url.password)throw Error('차량 사진 경로를 확인해 주세요');
  const r=await fetch(url,{headers:{authorization:'Bearer '+session,...(cookie?{Cookie:cookie}:{})},redirect:'error',signal:AbortSignal.timeout(7000)});if(!r.ok)return null;
  if(Number(r.headers.get('content-length')||0)>8*1024*1024)return null;
  const bytes=Buffer.from(await r.arrayBuffer());if(bytes.length>8*1024*1024)return null;
  const tmp=path.join(here,'data',randomUUID()+'.jpg');await fs.writeFile(tmp,bytes);
  try{return await powershell("Add-Type -AssemblyName System.Drawing;$i=[Drawing.Image]::FromFile("+quote(tmp)+");try{$b=New-Object Drawing.Bitmap(400,225);$g=[Drawing.Graphics]::FromImage($b);try{$g.DrawImage($i,0,0,400,225);$m=New-Object IO.MemoryStream;$b.Save($m,[Drawing.Imaging.ImageFormat]::Jpeg);if($m.Length -le 39000){[Convert]::ToBase64String($m.ToArray())};$m.Dispose()}finally{$g.Dispose();$b.Dispose()}}finally{$i.Dispose()}");}finally{await fs.unlink(tmp).catch(()=>{});}
 }
 const journalFile=path.join(here,'data','journal.json');let journal={};try{journal=JSON.parse(await fs.readFile(journalFile,'utf8'));}catch{}
 const send=async(endpoint,body)=>{const r=await fetch(RELAY+endpoint,{method:body?'POST':'GET',headers:{authorization:'Bearer '+token,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('중계 연결 오류 '+r.status);return r.json();};
 const execute=createParkingExecutor({sk,photo,authorize:id=>send('/v1/parking-bridge/authorize',{id})});
 for(const [id,item] of Object.entries(journal))if(item.status==='PROCESSING'){item.status='UNKNOWN';item.result={error:'이전 할인·방문권 처리 결과를 SK쉴더스에서 확인해 주세요'};}
 await save(journalFile,journal);
 console.log('HODI PASS parking connector started.');
 setInterval(()=>send('/v1/parking-bridge/heartbeat',{}).catch(()=>{}),5000).unref();
 for(;;){try{
  for(const [id,item] of Object.entries(journal))if(!item.sent&&item.status!=='PROCESSING'){await send('/v1/parking-bridge/results',{id,status:item.status,result:item.result});item.sent=true;await save(journalFile,journal);}
  const {commands}=await send('/v1/parking-bridge/commands');
  for(const job of commands){
   if(journal[job.id])continue;
   const mutation=['apply','register'].includes(job.action);
   if(mutation){journal[job.id]={status:'PROCESSING',result:{},createdAt:Date.now()};await save(journalFile,journal);}
   let outcome;try{outcome={status:'DONE',result:await execute(job)};}catch(e){outcome={status:e.uncertain?'UNKNOWN':'FAILED',result:{error:e.uncertain?'처리 결과 확인이 필요합니다. SK쉴더스에서 적용 여부를 확인해 주세요.':String(e.message).slice(0,180)}};}
   journal[job.id]={...outcome,mutation,createdAt:Date.now(),sent:false};await save(journalFile,journal);
  }
  for(const [id,item] of Object.entries(journal))if(item.sent&&Date.now()-item.createdAt>(item.mutation?7*86400000:60000))delete journal[id];
 }catch(e){console.error(new Date().toISOString(),'Parking connection unavailable:',e.name);}
 await new Promise(r=>setTimeout(r,1000));
 }
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});

﻿$ErrorActionPreference = 'Stop'
$mutex = New-Object System.Threading.Mutex($false, 'Local\HODIPASSParkingConnector')
if (-not $mutex.WaitOne(0)) { exit 0 }
try {
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'data\config.json') -Raw | ConvertFrom-Json
    $node = Join-Path $config.parkingRoot 'runtime\node.exe'
    if (-not (Test-Path -LiteralPath $node)) { throw 'HODIPARKING runtime not found' }
    $log = Join-Path $PSScriptRoot 'data\connector.log'
    if ((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).Length -gt 2MB) { Move-Item -LiteralPath $log -Destination ($log + '.previous') -Force }
    & $node (Join-Path $PSScriptRoot 'ParkingBridge.mjs') *> $log
} finally { $mutex.ReleaseMutex(); $mutex.Dispose() }

export function entryMillis(value){
 let s=String(value||'').trim();if(/^\d{14}$/.test(s))s=s.replace(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/,'$1-$2-$3T$4:$5:$6');
 s=s.replace(' ','T');if(/^\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d)?$/.test(s))s+='+09:00';return Date.parse(s);
}
export function vehicleResults(rows,query='',now=Date.now(),offset=0){
 const q=String(query).replace(/[\s-]/g,'');
 const items=rows.filter(v=>!v.outDate&&!v.outDateTime&&String(v.vehicleNo||'').replace(/[\s-]/g,'').includes(q)).filter(v=>q||Number.isFinite(entryMillis(v.inDate))&&(now-entryMillis(v.inDate)>=0&&now-entryMillis(v.inDate)<10*86400000)).sort((a,b)=>entryMillis(b.inDate)-entryMillis(a.inDate));
 return {items:items.slice(offset,offset+30).map(v=>({inSn:String(v.sn),vehicleNo:String(v.vehicleNo),inDate:String(v.inDate||''),carType:String(v.carType||v.ticketType||'일반차량'),hasPhoto:Boolean(v.imImagePath)})),total:items.length,nextOffset:offset+30<items.length?offset+30:null};
}
export function visitorPayload(b){
 const plate=String(b.vehicleNo||'').replace(/[\s-]/g,'');
 if(!/^[가-힣]{0,2}\d{2,3}[가-힣]\d{4}$/.test(plate))throw Error('차량번호 전체를 입력해 주세요');
 for(const key of ['startDate','endDate'])if(!/^\d{4}-\d\d-\d\d$/.test(b[key]||'')||!Number.isFinite(Date.parse(b[key]))||new Date(b[key]+'T00:00:00Z').toISOString().slice(0,10)!==b[key])throw Error('방문 예정일을 확인해 주세요');
 if(b.startDate>b.endDate||Date.parse(b.endDate)-Date.parse(b.startDate)>365*86400000)throw Error('방문 기간을 확인해 주세요');
 return [{vehicleNo:plate,effectDate:b.startDate+' 00:00:00',expireDate:b.endDate+' 23:59:59',corpSn:1,ticketType:'VISITTICKET',delYn:'N',tel:String(b.phone||'').replace(/\D/g,'').slice(0,11),etc:[String(b.name||'').slice(0,40),String(b.memo||'').slice(0,200)].filter(Boolean).join(' · ')}];
}
export function discountPayload(job,allowed){
 const selections=job.selections||[{classSn:job.classSn,quantity:job.quantity}];
 if(!Array.isArray(selections)||!selections.length||selections.length>8||new Set(selections.map(s=>String(s.classSn))).size!==selections.length)throw Error('할인권 선택을 확인해 주세요');
 return selections.map(s=>{
  const ticket=allowed.find(t=>String(t.corpTicketClass?.sn)===String(s.classSn));
  if(!ticket||!Number.isFinite(Number(ticket.ableCnt))||!Number.isFinite(Number(ticket.totalCnt))||!Number.isInteger(s.quantity)||s.quantity<1||s.quantity>10||s.quantity>Math.min(Number(ticket.ableCnt),Number(ticket.totalCnt)))throw Error('사용 가능한 할인권 수량을 확인해 주세요');
  return {inSn:Number(job.inSn),classSn:Number(s.classSn),cnt:s.quantity,corpSn:1};
 });
}

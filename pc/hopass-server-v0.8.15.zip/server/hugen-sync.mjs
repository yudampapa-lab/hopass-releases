import {readHugenRoster,IMPORT_COMPANIES} from './hugen-roster.mjs';import {readFileSync,writeFileSync,renameSync} from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
export function createHugenSync({configPath,cloud,readRoster=readHugenRoster,clock=Date.now}){
 const file=path.join(path.dirname(configPath),'hugen-sync-status.json');let status={state:'waiting',companies:['호디','데이터누리']},running=null;
 try{status={...status,...JSON.parse(readFileSync(file,'utf8'))}}catch{}
 const save=()=>{const temp=file+'.tmp';writeFileSync(temp,JSON.stringify(status),{mode:0o600});renameSync(temp,file)};
 async function run(force=false){if(running)return running;running=(async()=>{status={...status,state:'reading',lastAttemptAt:clock()};try{
  const source=await readRoster(configPath);if(source.complete!==true||!Array.isArray(source.allUserIds)||!source.allUserIds.length||new Set(source.allUserIds).size!==source.allUserIds.length)throw Error('hugen_roster_incomplete');
  const roster={...source,items:source.items.filter(i=>IMPORT_COMPANIES.includes(i.company)).map(i=>({id:i.id,name:i.name,company:i.company,startDate:i.startDate,endDate:i.endDate,deviceNos:i.deviceNos}))},day=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul'}).format(new Date(clock())),digest=createHash('sha256').update(JSON.stringify({items:roster.items,day})).digest('hex');let imported=0,skipped=0;
  if(force||digest!==status.digest){for(let i=0;i<roster.items.length;i+=20){const value=await cloud('/v1/bridge/management/hugen-import','POST',{source:'hugen-live',observedAt:clock(),preview:false,items:roster.items.slice(i,i+20)});imported+=value.imported.length;skipped+=value.skipped.length;}}
  const lifecycle=await cloud('/v1/bridge/management/hugen-reconcile','POST',{source:'hugen-live',complete:roster.complete,allUserIds:roster.allUserIds,observedAt:clock(),added:imported,items:roster.items.map(({id,name,company})=>({id,name,company}))});
  status={state:'ok',companies:['호디','데이터누리'],lastAttemptAt:status.lastAttemptAt,lastSuccessAt:clock(),sourceCount:roster.items.length,added:imported,skipped,unchanged:!force&&digest===status.digest,digest,disabled:lifecycle.disabled,pending:lifecycle.pending};save();
 }catch(e){status={...status,state:'error',error:String(e.message||'hugen_sync_failed').slice(0,150)};try{save()}catch{}}return {...status,digest:undefined};})().finally(()=>{running=null});return running;}
 const first=setTimeout(()=>void run(),10000);first.unref();const timer=setInterval(()=>void run(),300000);timer.unref();
 return {run,status:()=>({...status,digest:undefined}),stop(){clearTimeout(first);clearInterval(timer)}};
}

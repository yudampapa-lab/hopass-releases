import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import {randomBytes,createHash,createCipheriv,createDecipheriv} from 'node:crypto';
import {cameraSettings,saveCamera,loadCamera,openCamera} from './camera-source.mjs';
import {normalizePlayEmail,playAccountStore} from './play-accounts.mjs';
import {createHugenSync} from './hugen-sync.mjs';
import {localRetentionPreview} from './retention-preview.mjs';

const page=readFileSync(new URL('./admin.html',import.meta.url),'utf8');

function save(path,value){const temp=path+'.tmp';writeFileSync(temp,JSON.stringify(value,null,2),{mode:0o600});renameSync(temp,path)}
async function requestBody(req){let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>16384)throw Object.assign(Error('body_too_large'),{code:413})}try{return JSON.parse(text)}catch{throw Object.assign(Error('invalid_json'),{code:400})}}
function vaultPath(configPath){return configPath.replace(/[\\/]config\.json$/i,'/admin-tokens.json')}
function vaultRead(path){try{return JSON.parse(readFileSync(path,'utf8'))}catch(e){if(e.code==='ENOENT')return {};throw e}}
function vaultKey(bridgeToken){return createHash('sha256').update('HOPASS admin token vault\0'+bridgeToken).digest()}
function seal(token,bridgeToken){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',vaultKey(bridgeToken),iv),data=Buffer.concat([cipher.update(token,'utf8'),cipher.final()]);return {iv:iv.toString('base64url'),data:data.toString('base64url'),tag:cipher.getAuthTag().toString('base64url')}}
function open(value,bridgeToken){const decipher=createDecipheriv('aes-256-gcm',vaultKey(bridgeToken),Buffer.from(value.iv,'base64url'));decipher.setAuthTag(Buffer.from(value.tag,'base64url'));return Buffer.concat([decipher.update(Buffer.from(value.data,'base64url')),decipher.final()]).toString('utf8')}
export function createAdmin({configPath,credentialsPath,relayBase,hash}){
 const playAccounts=playAccountStore(configPath);
 async function cloud(path,method='GET',body){const credentials=JSON.parse(readFileSync(credentialsPath));const headers={authorization:`Bearer ${credentials.bridgeToken}`,'content-type':'application/json'};const response=await fetch(relayBase+path,{method,headers,redirect:'error',body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(8000)});const value=await response.json();if(!response.ok)throw Object.assign(Error(value.error||('cloud_http_'+response.status)),{code:response.status});return value}
 const hugenSync=createHugenSync({configPath,cloud});
 const handler=async function(req,res,path){
  const send=(code,value,type='application/json; charset=utf-8')=>{res.writeHead(code,{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'});res.end(type.startsWith('application/json')?JSON.stringify(value):value)};
  try{
   if(path==='/admin'&&req.method==='GET'){send(200,page,'text/html; charset=utf-8');return true}
   if(path==='/v1/admin/rebind'&&req.method==='POST'){const b=await requestBody(req),credentials=JSON.parse(readFileSync(credentialsPath));const response=await fetch(relayBase+'/v1/admin/rebind',{method:'POST',headers:{'x-hopass-recovery-code':String(b.code||''),'content-type':'application/json'},redirect:'error',body:JSON.stringify({bridgeToken:credentials.bridgeToken}),signal:AbortSignal.timeout(8000)});const value=await response.json();if(!response.ok)throw Object.assign(Error(value.error||('cloud_http_'+response.status)),{code:response.status});send(200,value);return true}
   if(path==='/v1/admin/hugen-sync'&&req.method==='GET'){send(200,hugenSync.status());return true}
   if(path==='/v1/admin/hugen-sync'&&req.method==='POST'){send(200,await hugenSync.run(true));return true}
   if(path==='/v1/admin/config'&&req.method==='GET'){send(200,playAccounts.decorate(await cloud('/v1/bridge/admin/config')));return true}
   if(path==='/v1/admin/management/parking-account'){send(405,{error:'company_parking_account_fixed'});return true}
   if(/^\/v1\/admin\/management(?:\/(companies|employees|parking-account))?$/.test(path)&&['GET','POST'].includes(req.method)){
    const b=req.method==='POST'?await requestBody(req):undefined;
    const email=b?.playEmail===undefined?undefined:normalizePlayEmail(b.playEmail);
    const result=await cloud(path.replace('/v1/admin/management','/v1/bridge/management'),req.method,b);
    if(email!==undefined&&b?.id)playAccounts.set(String(b.id),email);
    send(200,result);return true;
   }
   if(path==='/v1/admin/retention-preview'){
    if(req.method!=='GET'){send(405,{error:'preview_only'});return true}
    const [report,local]=await Promise.all([cloud('/v1/bridge/admin/retention-preview'),localRetentionPreview(configPath)]);
    send(200,{...report,local});return true;
   }
   if(path==='/v1/admin/employees/play-account'&&req.method==='POST'){
    const b=await requestBody(req),id=String(b.id||'').trim(),email=normalizePlayEmail(b.playEmail);
    const cfg=await cloud('/v1/bridge/admin/config');if(!cfg.employees.some(e=>e.id===id))throw Object.assign(Error('employee_not_found'),{code:404});
    playAccounts.set(id,email);send(200,{ok:true,playEmail:email});return true;
   }
   if(path==='/v1/admin/cameras'&&req.method==='GET'){send(200,{cameras:cameraSettings(credentialsPath)});return true}
   if(path==='/v1/admin/cameras'&&req.method==='POST'){saveCamera(credentialsPath,await requestBody(req));send(200,{ok:true});return true}
   const cameraMatch=path.match(/^\/v1\/admin\/cameras\/(f1-main|b1-parking|b2-parking)\/snapshot$/);
   if(cameraMatch&&req.method==='GET'){const response=await openCamera(loadCamera(credentialsPath,cameraMatch[1]),{signal:AbortSignal.timeout(7000)});const bytes=Buffer.from(await response.arrayBuffer());if(bytes.length>512000)throw Error('camera_frame_too_large');res.writeHead(200,{'content-type':'image/jpeg','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(bytes);return true}
   if(/^\/v1\/admin\/parking\/(permissions|pairing|history|resolve)$/.test(path)&&['GET','POST'].includes(req.method)){
    send(200,await cloud(path.replace('/v1/admin/parking/','/v1/bridge/parking-admin/'),req.method,req.method==='POST'?await requestBody(req):undefined));return true;
   }
   const employeeMatch=path.match(/^\/v1\/admin\/employees\/([^/]+)$/);if(employeeMatch&&req.method==='DELETE'){const id=decodeURIComponent(employeeMatch[1]);await cloud('/v1/bridge/admin/employees/'+encodeURIComponent(id),'DELETE');const cfg=JSON.parse(readFileSync(configPath));cfg.employees=cfg.employees.filter(e=>e.id!==id);save(configPath,cfg);const pathToVault=vaultPath(configPath),vault=vaultRead(pathToVault);delete vault[id];save(pathToVault,vault);playAccounts.remove(id);send(200,{ok:true});return true}
   if(path==='/v1/admin/doors'&&req.method==='POST'){const b=await requestBody(req);await cloud('/v1/bridge/admin/doors','POST',b);const cfg=JSON.parse(readFileSync(configPath)),beacons=(Array.isArray(b.beacons)&&b.beacons.length?b.beacons:[{uuid:b.uuid,major:b.major,minor:b.minor}]).map(v=>({uuid:String(v.uuid).toLowerCase(),major:Number(v.major),minor:Number(v.minor)})),nfcTagUids=(Array.isArray(b.nfcTagUids)?b.nfcTagUids:[]).map(v=>String(v).replace(/[^0-9a-f]/gi,'').toUpperCase()),door={id:b.id,name:b.name,enabled:b.enabled===true,cooldownSeconds:Number(b.cooldownSeconds??10),detectionMeters:Number(b.detectionMeters??10),hugen:{deviceNo:b.deviceNo,deviceTID:b.deviceTID,commType:2,tcpPort:5001,verifiedOnLivePC:false},beacon:beacons[0],beacons,nfcTagUids};cfg.doors=[...cfg.doors.filter(d=>d.id!==b.id),door];save(configPath,cfg);send(200,{ok:true,beaconCount:beacons.length,nfcTagCount:nfcTagUids.length});return true}
   if(path==='/v1/admin/employees/permissions'&&req.method==='POST'){const b=await requestBody(req);await cloud('/v1/bridge/admin/employees/permissions','POST',b);const cfg=JSON.parse(readFileSync(configPath)),employee=cfg.employees.find(e=>e.id===b.id);if(!employee)throw Object.assign(Error('employee_not_found'),{code:404});employee.name=b.name;employee.enabled=b.enabled!==false;employee.doors=b.doorIds;save(configPath,cfg);send(200,{ok:true});return true}
   if(path==='/v1/admin/employees'&&req.method==='POST'){
    const b=await requestBody(req),playEmail=b.playEmail===undefined?undefined:normalizePlayEmail(b.playEmail),token=randomBytes(32).toString('base64url');
    const registration={...b,token};delete registration.playEmail;
    const issued=await cloud('/v1/bridge/admin/employees','POST',registration);
    const cfg=JSON.parse(readFileSync(configPath)),employee={id:b.id,name:b.name,enabled:b.enabled!==false,tokenHash:hash(token),doors:b.doorIds};
    cfg.employees=[...cfg.employees.filter(e=>e.id!==b.id),employee];save(configPath,cfg);
    const credentials=JSON.parse(readFileSync(credentialsPath)),pathToVault=vaultPath(configPath),vault=vaultRead(pathToVault);vault[b.id]=seal(token,credentials.bridgeToken);save(pathToVault,vault);
    if(playEmail!==undefined)playAccounts.set(b.id,playEmail);
    send(200,{ok:true,activationCode:issued.activationCode,expiresAt:issued.expiresAt});return true;
   }
   return false;
  }catch(e){send(typeof e.code==='number'&&e.code>=400&&e.code<=599?e.code:500,{error:e.message||'admin_error'});return true}
 };handler.close=()=>hugenSync.stop();return handler;
}

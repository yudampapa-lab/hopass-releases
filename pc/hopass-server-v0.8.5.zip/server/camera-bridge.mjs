import {loadCamera,openCamera,jpegFrames,CAMERAS,cameraSettings,saveCamera} from './camera-source.mjs';
const delay=ms=>new Promise(r=>setTimeout(r,ms));
export async function startCameraBridge({base,token,credentials,stopping=()=>false}){
 if(typeof WebSocket==='undefined'){console.error('Camera relay needs Node.js 22 or later');return;}
 const root=new URL(base);if(root.protocol!=='https:')return;
 // Provision only missing local camera settings through the authenticated PC bridge.
 // Passwords never appear in release files, mobile responses, URLs or logs.
 try{if(cameraSettings(credentials).some(c=>!c.configured)){
  const response=await fetch(new URL('/v1/bridge/cameras/settings',root),{headers:{authorization:'Bearer '+token},redirect:'error',signal:AbortSignal.timeout(7000)});
  if(response.status===200){const setup=await response.json();for(const c of setup.cameras||[])if(!cameraSettings(credentials).find(s=>s.id===c.id)?.configured)saveCamera(credentials,c);
   if(cameraSettings(credentials).every(c=>c.configured))await fetch(new URL('/v1/bridge/cameras/settings-ack',root),{method:'POST',headers:{authorization:'Bearer '+token},redirect:'error',signal:AbortSignal.timeout(5000)});
  }
 }}catch{console.error('CCTV settings need administrator attention');}
 for(const spec of CAMERAS)(async()=>{while(!stopping()){
  let ws,active=null,demand=0,working=false,preferSnapshots=false,sourceConfig='',lastSent=0;
  const sendStatus=status=>{if(ws?.readyState===1)ws.send(JSON.stringify({status}));};
  const pump=async()=>{if(working||!demand||ws?.readyState!==1)return;working=true;try{while(demand&&ws.readyState===1&&!stopping()){
   active=new AbortController();let timer=setTimeout(()=>active.abort(),8000);
   try{
    const camera=loadCamera(credentials,spec.id),configKey=camera.profile+':'+camera.channel;let response;if(configKey!==sourceConfig){sourceConfig=configKey;preferSnapshots=false;}
    try{response=await openCamera(camera,{stream:!preferSnapshots,signal:active.signal});}catch(e){if(e.message==='camera_credentials_required')throw e;if(e.message==='camera_format_unsupported')preferSnapshots=true;response=await openCamera(camera,{signal:active.signal});}
    clearTimeout(timer);timer=setTimeout(()=>active?.abort(),10000);
    for await(const frame of jpegFrames(response.body)){clearTimeout(timer);timer=setTimeout(()=>active?.abort(),10000);if(!demand||ws.readyState!==1||stopping())break;if(ws.bufferedAmount<600000&&Date.now()-lastSent>=200){lastSent=Date.now();ws.send(frame);sendStatus('camera_live');}}
   }catch(e){sendStatus(e.message==='camera_credentials_required'?'camera_credentials_required':'camera_unavailable');if(demand)await delay(1500);}finally{clearTimeout(timer);active.abort();active=null;await delay(preferSnapshots?1500:200);}
  }}finally{working=false;}};
  try{
   const url=new URL('/v1/bridge/cameras/'+spec.id+'/connect',root);url.protocol='wss:';
   await new Promise(resolve=>{ws=new WebSocket(url,['hopass-camera','auth.'+token]);ws.addEventListener('message',e=>{try{const value=JSON.parse(e.data);demand=Math.max(0,Math.min(32,Number(value.viewers)||0));if(!demand)active?.abort();else void pump();}catch{}});ws.addEventListener('close',()=>{active?.abort();resolve()});ws.addEventListener('error',()=>{active?.abort();try{ws.close()}catch{}resolve()});});
  }catch{}finally{active?.abort();try{ws?.close()}catch{}}
  await delay(2500);
 }})().catch(()=>console.error('Camera relay stopped:',spec.id));
}

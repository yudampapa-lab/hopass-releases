import {createHash,randomBytes,createCipheriv,createDecipheriv} from 'node:crypto';
import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {Readable} from 'node:stream';
export const CAMERAS=[{id:'f1-main',name:'정문',ip:'192.168.10.22'},{id:'b1-parking',name:'지하1층',ip:'192.168.10.16'},{id:'b2-parking',name:'지하2층',ip:'192.168.10.10'}];
const key=token=>createHash('sha256').update('HOPASS CCTV vault\0'+token).digest();
const file=credentials=>path.join(path.dirname(credentials),'cameras.json');
function settings(credentials){try{return JSON.parse(readFileSync(file(credentials),'utf8'))}catch(e){if(e.code==='ENOENT')return {};throw e}}
export function cameraSettings(credentials){const values=settings(credentials);return CAMERAS.map(c=>({...c,username:values[c.id]?.username||'admin',profile:values[c.id]?.profile||1,channel:values[c.id]?.channel||0,configured:Boolean(values[c.id]?.secret)}));}
export function saveCamera(credentials,b){
 if(!CAMERAS.some(c=>c.id===b.id)||typeof b.username!=='string'||!b.username.trim()||b.username.length>80||!Number.isInteger(b.profile)||b.profile<1||b.profile>10||!Number.isInteger(b.channel)||b.channel<0||b.channel>15||typeof b.password!=='string'||b.password.length>128)throw Error('CCTV 계정·프로필·채널을 확인해 주세요');
 const all=settings(credentials),old=all[b.id];if(!old?.secret&&!b.password)throw Error('CCTV 비밀번호를 입력해 주세요');
 let secret=old?.secret;if(b.password){const token=JSON.parse(readFileSync(credentials)).bridgeToken,iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key(token),iv),bytes=Buffer.concat([cipher.update(b.password,'utf8'),cipher.final()]);secret={iv:iv.toString('base64'),data:bytes.toString('base64'),tag:cipher.getAuthTag().toString('base64')};}
 all[b.id]={username:b.username.trim(),profile:b.profile,channel:b.channel,secret};const target=file(credentials);writeFileSync(target+'.tmp',JSON.stringify(all),{mode:0o600});renameSync(target+'.tmp',target);
}
export function loadCamera(credentials,id){
 const camera=CAMERAS.find(c=>c.id===id),value=settings(credentials)[id];if(!camera||!value?.secret)throw Error('camera_credentials_required');
 const token=JSON.parse(readFileSync(credentials)).bridgeToken,s=value.secret,decipher=createDecipheriv('aes-256-gcm',key(token),Buffer.from(s.iv,'base64'));decipher.setAuthTag(Buffer.from(s.tag,'base64'));
 return {...camera,...value,password:Buffer.concat([decipher.update(Buffer.from(s.data,'base64')),decipher.final()]).toString('utf8')};
}
const digest=(algorithm,s)=>createHash(algorithm).update(s).digest('hex');
const authChallenges=new Map(),digestSessions=new Map();
export function digestAuthorization(challenge,{username,password},uri){
 if(!/^Digest /i.test(challenge))throw Error('camera_auth_unsupported');const fields={};for(const m of challenge.matchAll(/(\w+)=(?:"([^"]*)"|([^,\s]+))/g))fields[m[1]]=m[2]??m[3];
 const algorithm=(fields.algorithm||'MD5').toUpperCase();if(!['MD5','SHA-256'].includes(algorithm)||!fields.realm||!fields.nonce)throw Error('camera_auth_unsupported');
 const sessionKey=username+':'+fields.realm+':'+fields.nonce;let session=digestSessions.get(sessionKey);if(!session){if(digestSessions.size>32)digestSessions.clear();session={cnonce:randomBytes(16).toString('hex'),count:0};digestSessions.set(sessionKey,session);}session.count++;
 const hash=algorithm==='MD5'?'md5':'sha256',nc=session.count.toString(16).padStart(8,'0'),cnonce=session.cnonce,qop=fields.qop?.split(',').map(v=>v.trim()).includes('auth')?'auth':null;
 if(fields.qop&&!qop)throw Error('camera_auth_unsupported');
 const a1=digest(hash,username+':'+fields.realm+':'+password),a2=digest(hash,'GET:'+uri),response=digest(hash,a1+':'+fields.nonce+':'+(qop?nc+':'+cnonce+':'+qop+':':'')+a2);
 const quote=v=>'"'+String(v).replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"';
 return 'Digest username='+quote(username)+', realm='+quote(fields.realm)+', nonce='+quote(fields.nonce)+', uri='+quote(uri)+', response='+quote(response)+', algorithm='+algorithm+(fields.opaque?', opaque='+quote(fields.opaque):'')+(qop?', qop=auth, nc='+nc+', cnonce='+quote(cnonce):'');
}
function cameraHttp(url,options){return new Promise((resolve,reject)=>{const req=http.get(url,{agent:false,headers:options.headers,signal:options.signal},res=>{const headers=new Headers();for(const [k,v] of Object.entries(res.headers))if(v!==undefined)headers.set(k,Array.isArray(v)?v.join(', '):v);resolve({status:res.statusCode,ok:res.statusCode>=200&&res.statusCode<300,headers,body:Readable.toWeb(res)});});req.on('error',reject);});}
export async function openCamera(camera,{stream=false,signal,fetcher=cameraHttp}={}){
 // Official Hanwha SUNAPI MJPEG/snapshot endpoints; never accept arbitrary hosts.
 if(!CAMERAS.some(c=>c.id===camera.id&&c.ip===camera.ip))throw Error('invalid_camera');
 const uri='/stw-cgi/video.cgi?msubmenu='+(stream?'stream':'snapshot')+'&action=view&Profile='+camera.profile+(camera.channel>0?'&Channel='+camera.channel:'')+(stream?'&CodecType=MJPEG':'');
 const options={redirect:'error',signal,headers:{connection:'close'}},url='http://'+camera.ip+uri,cacheKey=camera.ip+':'+camera.username,cached=authChallenges.get(cacheKey);
 if(cached)options.headers.authorization=digestAuthorization(cached,camera,uri);
 let r=await fetcher(url,options);if(r.status===401){const challenge=r.headers.get('www-authenticate')||'';await r.body?.cancel();authChallenges.set(cacheKey,challenge);r=await fetcher(url,{...options,headers:{...options.headers,authorization:digestAuthorization(challenge,camera,uri)}});}
 if(!r.ok){await r.body?.cancel();throw Error(r.status===401||r.status===403?'camera_credentials_required':'camera_unavailable');}
 const type=r.headers.get('content-type')||'';if(!/(image\/jpeg|multipart\/x-mixed-replace)/i.test(type)){await r.body?.cancel();throw Error('camera_format_unsupported');}
 return r;
}
export async function* jpegFrames(body){
 let bytes=Buffer.alloc(0);for await(const chunk of body){bytes=Buffer.concat([bytes,Buffer.from(chunk)]);if(bytes.length>1024*1024)throw Error('camera_frame_too_large');for(;;){const start=bytes.indexOf(Buffer.from([255,216]));if(start<0){bytes=bytes.subarray(-1);break;}if(start>0)bytes=bytes.subarray(start);const end=bytes.indexOf(Buffer.from([255,217]),2);if(end<0)break;const frame=bytes.subarray(0,end+2);bytes=bytes.subarray(end+2);if(frame.length<=512000)yield frame;}}
}

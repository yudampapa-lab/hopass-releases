param([Parameter(Mandatory=$true)][string]$Database,[Parameter(Mandatory=$true)][string]$CompaniesBase64)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if(-not(Test-Path -LiteralPath $Database)){throw 'HUGEN database not found'}
function Normal([string]$value){return ([regex]::Replace(([regex]::Replace($value,'[\s()\u321c]','')),'\uC8FC\uC2DD\uD68C\uC0AC','') -replace '^\uC8FC','')}
$names=ConvertFrom-Json ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($CompaniesBase64)))
$wanted=@{};foreach($name in $names){$wanted[(Normal $name)]=$name}
$builder=New-Object Data.OleDb.OleDbConnectionStringBuilder
$builder['Provider']='Microsoft.Jet.OLEDB.4.0';$builder['Data Source']=$Database;$builder['Mode']='Read'
$c=New-Object Data.OleDb.OleDbConnection($builder.ConnectionString);$c.Open()
function Rows([string]$query){$q=$c.CreateCommand();$q.CommandText=$query;$q.CommandTimeout=12;$r=$q.ExecuteReader();try{while($r.Read()){$row=@{};for($i=0;$i -lt $r.FieldCount;$i++){$row[$r.GetName($i)]=if($r.IsDBNull($i)){$null}else{$r.GetValue($i)}};Write-Output $row}}finally{$r.Dispose();$q.Dispose()}}
try{
 $g1=@{};foreach($g in @(Rows 'SELECT UserGroup1,UserGroup1Name FROM tbUserGroup1')){$g1[[string]$g.UserGroup1]=[string]$g.UserGroup1Name}
 $g2=@{};foreach($g in @(Rows 'SELECT UserGroup1,UserGroup2,UserGroup2Name FROM tbUserGroup2')){$g2[([string]$g.UserGroup1+':'+[string]$g.UserGroup2)]=[string]$g.UserGroup2Name}
 $g3=@{};foreach($g in @(Rows 'SELECT UserGroup3,UserGroup3Name FROM tbUserGroup3')){$g3[[string]$g.UserGroup3]=[string]$g.UserGroup3Name}
 $users=New-Object Collections.Generic.List[object]
 foreach($u in @(Rows 'SELECT UserNo,UserName,UserGroup1,UserGroup2,UserGroup3,StartDate,EndDate FROM tbUser')){
  $matches=@();foreach($label in @($g1[[string]$u.UserGroup1],$g2[([string]$u.UserGroup1+':'+[string]$u.UserGroup2)],$g3[[string]$u.UserGroup3])){$normal=Normal $label;if($wanted.ContainsKey($normal)){$matches+=$wanted[$normal]}}
  $matches=@($matches|Select-Object -Unique);if($matches.Count -ne 1){continue}
  $devices=New-Object Collections.Generic.List[int];$q=$c.CreateCommand();$q.CommandText='SELECT DeviceNo FROM tbUserDevice WHERE UserNo=?';[void]$q.Parameters.Add('?',200,30);$q.Parameters[0].Value=[string]$u.UserNo;$r=$q.ExecuteReader();try{while($r.Read()){if(-not $r.IsDBNull(0)){$devices.Add([int]$r[0])}}}finally{$r.Dispose();$q.Dispose()}
  $users.Add([ordered]@{id=([string]$u.UserNo).Trim();name=([string]$u.UserName).Trim();company=$matches[0];startDate=[string]$u.StartDate;endDate=[string]$u.EndDate;deviceNos=@($devices)})
 }
 [ordered]@{source='hugen-live';observedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();items=@($users.ToArray())}|ConvertTo-Json -Depth 5 -Compress
}finally{$c.Dispose()}

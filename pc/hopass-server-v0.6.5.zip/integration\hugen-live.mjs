import net from 'node:net';import http from 'node:http';import fs from 'node:fs';import {spawn} from 'node:child_process';import {encodeTransientOpen,decodeResponse} from './hugen-codec.mjs';
const configPath=process.env.HOPASS_LIVE_CONFIG;if(!configPath)throw Error('HOPASS_LIVE_CONFIG missing');
const cfg=JSON.parse(fs.readFileSync(configPath));if(cfg.mode!=='live-pilot'||cfg.deviceNo!==14||cfg.deviceTID!==1||cfg.listenAddress!=='127.0.0.1')throw Error('invalid live configuration');
const secret=fs.readFileSync(cfg.secretFile,'utf8').trim();if(secret.length<40)throw Error('invalid local secret');
let client=null,upstream=null,lastClientData=0,pending=null,held=[],rx=Buffer.alloc(0),lastEvent='STARTING';const audit=s=>{lastEvent=s.slice(0,180);fs.appendFileSync(cfg.auditFile,new Date().toISOString()+' '+s+'\n')};
const finish=(value)=>{if(!pending)return;clearTimeout(pending.timer);const p=pending;pending=null;rx=Buffer.alloc(0);if(client){client.resume();for(const b of held)upstream?.write(b)}held=[];p.resolve(value)};
function logAccess(userNo,id){return new Promise(resolve=>{const prefix=Array.isArray(cfg.logWriterArgsPrefix)?cfg.logWriterArgsPrefix:[];const p=spawn(cfg.logWriter,[...prefix,cfg.database,String(cfg.deviceNo),userNo,id],{windowsHide:true});let out='',err='',settled=false;const done=v=>{if(!settled){settled=true;resolve(v)}};p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>done({ok:false,detail:e.message}));p.on('exit',code=>done({ok:code===0,detail:(code===0?out:err).trim().slice(0,250)}));});}
function consume(chunk){
 if(!pending){client?.write(chunk);return}rx=Buffer.concat([rx,chunk]);
 while(rx.length>=4){const length=rx.readUInt16BE(2);if(rx[0]!==8||rx[1]!==4||length<9||length>1024){const pass=rx;rx=Buffer.alloc(0);client?.write(pass);finish({status:'DEVICE_REJECTED',detail:'invalid device response frame'});return}if(rx.length<length)return;
  const frame=Buffer.from(rx.subarray(0,length));rx=rx.subarray(length);
  if(frame[4]===cfg.deviceTID&&frame[5]===0x38){try{const decoded=decodeResponse(frame,{expectedTid:cfg.deviceTID,expectedCommand:0x38});const remainder=Buffer.from(rx);rx=Buffer.alloc(0);if(remainder.length)client?.write(remainder);if(decoded.responseCode!==0){audit('REJECT '+pending.id+' code='+decoded.responseCode);finish({status:'DEVICE_REJECTED',detail:'controller response '+decoded.responseCode});return}const current=pending;pending=null;clearTimeout(current.timer);logAccess(current.employeeId,current.id).then(result=>{if(client){client.resume();for(const b of held)upstream?.write(b)}held=[];audit((result.ok?'OPENED_RECORDED ':'OPENED_LOG_FAILED ')+current.id+' '+result.detail);current.resolve({status:result.ok?'OPENED_RECORDED':'OPENED_LOG_FAILED',detail:result.detail})});return}catch(e){finish({status:'DEVICE_REJECTED',detail:e.message});return}}
  client?.write(frame);
 }
}
const proxy=net.createServer(socket=>{
 if(client){socket.destroy();return}client=socket;upstream=net.connect({host:cfg.upstreamAddress,port:cfg.upstreamPort});audit('HUGEN_CONNECTED');
 socket.on('data',b=>{lastClientData=Date.now();if(pending)held.push(Buffer.from(b));else upstream?.write(b)});socket.on('close',()=>{client=null;upstream?.destroy();upstream=null;finish({status:'DEVICE_UNAVAILABLE',detail:'HUGEN disconnected'})});socket.on('error',()=>{});
 upstream.on('connect',()=>audit('CONTROLLER_CONNECTED'));upstream.on('data',consume);upstream.on('error',e=>{audit('UPSTREAM_ERROR '+e.message);finish({status:'DEVICE_UNAVAILABLE',detail:'controller connection error'});socket.destroy()});upstream.on('close',()=>{audit('CONTROLLER_CLOSED');socket.destroy()});
});
proxy.listen(cfg.listenPort,cfg.listenAddress,()=>audit('PROXY_LISTEN '+cfg.listenPort));
async function open(command){
 if(pending)return {status:'DEVICE_UNAVAILABLE',detail:'another command is pending'};if(!client||!upstream||upstream.destroyed)return {status:'DEVICE_UNAVAILABLE',detail:'HUGEN controller link is offline'};
 if(command.doorId!=='test-door-1005'||command.expiresAt<=Date.now()||typeof command.employeeId!=='string'||command.employeeId.length>20)return {status:'DEVICE_REJECTED',detail:'invalid command'};
 const wait=Math.max(0,150-(Date.now()-lastClientData));if(wait)await new Promise(r=>setTimeout(r,wait));if(!client||!upstream)return {status:'DEVICE_UNAVAILABLE',detail:'link lost'};
 client.pause();return new Promise(resolve=>{pending={...command,resolve,timer:setTimeout(()=>finish({status:'DEVICE_UNAVAILABLE',detail:'controller response timeout'}),5000)};upstream.write(encodeTransientOpen(cfg.deviceTID));audit('OPEN_SENT '+command.id+' user='+command.employeeId+' requestLatencyMs='+(Date.now()-(command.createdAt||Date.now())))});
}
const api=http.createServer(async(req,res)=>{const send=(code,o)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(o))};
 if(req.url==='/health'&&req.method==='GET')return send(200,{ok:true,mode:'live-pilot',hugenConnected:!!client,controllerConnected:!!upstream&&!upstream.destroyed,deviceNo:14,lastEvent});
 if(req.url!=='/open'||req.method!=='POST')return send(404,{error:'not_found'});if(req.headers.authorization!==`Bearer ${secret}`)return send(401,{error:'unauthorized'});
 let text='';for await(const b of req){text+=b;if(text.length>4096)return send(413,{error:'too_large'})}try{const result=await open(JSON.parse(text));send(result.status==='OPENED_RECORDED'?200:503,result)}catch(e){send(400,{status:'DEVICE_REJECTED',detail:e.message})}
});api.listen(cfg.apiPort,'127.0.0.1',()=>audit('API_LISTEN '+cfg.apiPort));
function stop(){finish({status:'DEVICE_UNAVAILABLE',detail:'integration stopping'});api.close();proxy.close();client?.destroy();upstream?.destroy();setTimeout(()=>process.exit(0),250)}process.on('SIGINT',stop);process.on('SIGTERM',stop);

// Translate an authenticated server deadline into the integration PC's clock.
// Subtract the entire round-trip (including a long-poll wait) conservatively;
// never extend the server's original 30-second lifetime or replay a command.
export function prepareBridgeCommand(command,{serverTime,responseDate,receivedAt,roundTripMs}){
 const precise=Number.isFinite(serverTime),serverNow=precise?serverTime:Date.parse(responseDate||'');
 if(!Number.isFinite(serverNow)||!Number.isFinite(receivedAt)||!Number.isFinite(roundTripMs)||roundTripMs<0)return {ok:false,detail:'trusted server clock unavailable'};
 if(!Number.isFinite(command.createdAt)||!Number.isFinite(command.expiresAt)||command.expiresAt<=command.createdAt||command.expiresAt-command.createdAt>30000)return {ok:false,detail:'invalid command lifetime'};
 const remaining=command.expiresAt-serverNow-roundTripMs-(precise?0:1000);
 if(remaining<=0||command.createdAt>serverNow+1000)return {ok:false,detail:'command expired before execution'};
 return {ok:true,clockOffsetMs:receivedAt-serverNow,command:{...command,createdAt:receivedAt-(serverNow-command.createdAt),expiresAt:receivedAt+Math.min(30000,remaining)}};
}

﻿#Requires -Version 5.1
param([string]$HugenDirectory,[string]$OutputRoot,[switch]$NoUI)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
if(!$HugenDirectory){
 if($NoUI){throw 'HugenDirectory is required with NoUI'}
 $picker=New-Object System.Windows.Forms.OpenFileDialog
 $picker.Title='운영 PC에 설치된 Hugen.exe를 선택하세요'
 $picker.Filter='HUGEN 프로그램 (Hugen.exe)|Hugen.exe'
 if($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0}
 $HugenDirectory=Split-Path -Parent $picker.FileName
}
$HugenDirectory=[IO.Path]::GetFullPath($HugenDirectory)
$exe=Join-Path $HugenDirectory 'Hugen.exe'
$database=Join-Path $HugenDirectory 'HugenData.mdb'
if(!(Test-Path -LiteralPath $exe) -or !(Test-Path -LiteralPath $database)){throw 'Hugen.exe와 HugenData.mdb가 함께 있는 설치 폴더를 선택해야 합니다.'}
if(!$OutputRoot){$OutputRoot=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'HOPASS\Diagnostics'}
$run=Join-Path ([IO.Path]::GetFullPath($OutputRoot)) ([DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $run -Force|Out-Null
$report=[ordered]@{
 app='HOPASS';reportVersion=1;createdAt=[DateTimeOffset]::Now.ToString('o');computerName=$env:COMPUTERNAME
 hugenDirectory=$HugenDirectory;hugenVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo($exe).FileVersion
 databaseLastWriteUtc=(Get-Item -LiteralPath $database).LastWriteTimeUtc.ToString('o')
 inspectionMode='read-only selected metadata';deviceCommandSent=$false;databaseRecordsWritten=$false;liveEnabled=$false
 expected=[ordered]@{deviceNo=14;deviceName='2층 사무실(도서관)';deviceTID=1;commType=2;tcpPort=5001}
 detectedDevices=@();mappingMatches=$false;requiredSchemaPresent=$false;hugenProcessRunning=$false;errors=@()
}
$connection=$null
try{
 $report.hugenProcessRunning=@(Get-Process -Name Hugen -ErrorAction SilentlyContinue).Count -gt 0
 foreach($provider in @('Microsoft.Jet.OLEDB.4.0','Microsoft.ACE.OLEDB.12.0','Microsoft.ACE.OLEDB.16.0')){
  $builder=New-Object System.Data.OleDb.OleDbConnectionStringBuilder
  $builder['Provider']=[string]$provider;$builder['Data Source']=[string]$database;$builder['Mode']='Read'
  $candidate=New-Object System.Data.OleDb.OleDbConnection($builder.ConnectionString)
  try{$candidate.Open();$connection=$candidate;break}catch{Write-Output ($provider+": "+$_.Exception.InnerException.Message);$candidate.Dispose()}
 }
 if(!$connection){throw '읽기 전용 DB 연결에 실패했습니다. HUGEN을 종료하거나 드라이버를 변경하지 말고 진단 결과를 전달하세요.'}
 $tables=$connection.GetOleDbSchemaTable([System.Data.OleDb.OleDbSchemaGuid]::Tables,@($null,$null,$null,'TABLE'))
 $names=@($tables.Rows|ForEach-Object{$_.TABLE_NAME.ToString().ToLowerInvariant()})
 $required=@('tbdevice','tbenterlist','tbuser','tbuserconfirm','tbuserdevice')
 $missing=@($required|Where-Object{$names -notcontains $_})
 $report.requiredSchemaPresent=$missing.Count -eq 0
 if($missing.Count){throw ('필수 테이블이 없습니다: '+($missing -join ', '))}
 $cmd=$connection.CreateCommand()
 $cmd.CommandText='SELECT DeviceNo, DeviceName, DeviceTID, CommType, TCPAddress, TCPPort FROM tbDevice WHERE DeviceNo = ? OR DeviceName = ?'
 [void]$cmd.Parameters.Add('DeviceNo',[System.Data.OleDb.OleDbType]::Integer);$cmd.Parameters[0].Value=14
 [void]$cmd.Parameters.Add('DeviceName',[System.Data.OleDb.OleDbType]::VarWChar,50);$cmd.Parameters[1].Value='2층 사무실(도서관)'
 $reader=$cmd.ExecuteReader()
 try{while($reader.Read()){
  $entry=[ordered]@{};for($i=0;$i -lt $reader.FieldCount;$i++){$entry[$reader.GetName($i)]=if($reader.IsDBNull($i)){$null}else{$reader.GetValue($i)}}
  $report.detectedDevices+=([pscustomobject]$entry)
 }}finally{$reader.Close();$cmd.Dispose()}
 $exact=@($report.detectedDevices|Where-Object{$_.DeviceNo -eq 14 -and $_.DeviceName -eq '2층 사무실(도서관)' -and $_.DeviceTID -eq 1 -and $_.CommType -eq 2 -and $_.TCPPort -eq 5001})
 $report.mappingMatches=$exact.Count -eq 1 -and $report.detectedDevices.Count -eq 1
}catch{$report.errors+=($_.Exception.Message + " | " + $_.ScriptStackTrace)}finally{if($connection){$connection.Close();$connection.Dispose()}}
$jsonPath=Join-Path $run 'HOPASS-diagnostics.json'
$report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $jsonPath -Encoding UTF8
$status=if($report.errors.Count){'진단 중 확인이 필요한 항목이 있습니다.'}elseif($report.mappingMatches){'2층 사무실(도서관)의 장비 매핑이 분석 사본과 일치합니다.'}else{'운영 설정과 분석 사본의 매핑이 다릅니다. 결과 확인이 필요합니다.'}
$summary=@"
HOPASS 운영 PC 진단

$status
PC: $($report.computerName)
HUGEN 버전: $($report.hugenVersion)
HUGEN 프로세스 감지: $($report.hugenProcessRunning)
장비 매핑 일치: $($report.mappingMatches)
필수 테이블 존재: $($report.requiredSchemaPresent)

실제 문 개방 명령: 전송하지 않음
DB 레코드 변경: 수행하지 않음
직원/지문/비밀번호/출입이력 레코드: 조회하지 않음
HUGEN 종료, 방화벽 변경, 서비스 등록: 수행하지 않음

이 결과는 설정 대조입니다. 실제 통신/문 열림/직원 출입기록 검증은 아닙니다.
Jet 공급자가 읽기 연결을 위해 임시 잠금 파일(.ldb)을 관리할 수 있습니다.
JSON 결과에는 대상 장비의 사내 IP가 포함됩니다. 공개 게시하지 마세요.

결과 파일: $jsonPath
오류: $($report.errors -join ' / ')
"@
$summary|Set-Content -LiteralPath (Join-Path $run 'RESULT.txt') -Encoding UTF8
Write-Output $summary
if(!$NoUI){[void][System.Windows.Forms.MessageBox]::Show($summary,'HOPASS 진단 결과');Start-Process -FilePath 'explorer.exe' -ArgumentList ('"'+$run+'"')}
if($report.errors.Count){exit 1}

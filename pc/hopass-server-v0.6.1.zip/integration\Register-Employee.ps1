﻿param([Parameter(Mandatory=$true)][string]$Root,[string]$HugenDirectory='C:\HUGEN')
$ErrorActionPreference='Stop';. (Join-Path $PSScriptRoot 'Integration-Common.ps1');. (Join-Path (Split-Path -Parent $PSScriptRoot) 'Common.ps1');Assert-X86
Add-Type -AssemblyName System.Windows.Forms
try{
 $log=Join-Path $Root 'logs\integration-ui.log';New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force|Out-Null;Add-Content -LiteralPath $log -Value ([DateTime]::Now.ToString('s')+' employee registration started') -Encoding UTF8
 $db=Join-Path $HugenDirectory 'HugenData.mdb';if(!(Test-Path -LiteralPath $db)){throw 'C:\HUGEN\HugenData.mdb를 찾을 수 없습니다.'}
 if(!(Test-Path -LiteralPath (Join-Path $Root 'data\config.json'))){Start-Hopass $Root}
 $c=Open-HugenDb $db;try{$q=$c.CreateCommand();$q.CommandText='SELECT U.UserNo,U.UserName FROM tbUser U INNER JOIN tbUserDevice D ON U.UserNo=D.UserNo WHERE D.DeviceNo=14 ORDER BY U.UserName,U.UserNo';$r=$q.ExecuteReader();$users=@();try{while($r.Read()){$users+=[pscustomobject]@{UserNo=[string]$r[0];Label=([string]$r[1]+'  ['+[string]$r[0]+']')}}}finally{$r.Dispose()}}finally{$c.Dispose()}
 if($users.Count -eq 0){throw '2층 사무실(장비 14) 출입 권한이 있는 HUGEN 직원이 없습니다.'}
 $form=New-Object Windows.Forms.Form;$form.Text='HOPASS 직원 연결';$form.Width=480;$form.Height=190;$form.StartPosition='CenterScreen';$form.TopMost=$true
 $label=New-Object Windows.Forms.Label;$label.Text='HUGEN 직원 선택 (장비 14 출입 권한 보유자)';$label.SetBounds(20,18,420,24);$form.Controls.Add($label)
 $combo=New-Object Windows.Forms.ComboBox;$combo.DropDownStyle='DropDownList';$combo.DisplayMember='Label';$combo.SetBounds(20,48,420,28);foreach($user in $users){[void]$combo.Items.Add($user)};$combo.SelectedIndex=0;$form.Controls.Add($combo)
 $button=New-Object Windows.Forms.Button;$button.Text='연결 토큰 발급';$button.SetBounds(300,92,140,34);$button.DialogResult=[Windows.Forms.DialogResult]::OK;$form.Controls.Add($button);$form.AcceptButton=$button
 if($form.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){exit 0};$selected=$combo.SelectedItem;$form.Dispose();$token=New-Secret
 $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($token)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
 $path=Join-Path $Root 'data\config.json';$cfg=Read-HopassJson $path;$others=@($cfg.employees|Where-Object{[string]$_.id -ne $selected.UserNo});$employee=[pscustomobject]@{id=$selected.UserNo;name=($selected.Label -replace '\s+\[[^\]]+\]$','');enabled=$true;tokenHash=$hash;doors=@('test-door-1005')};$cfg.employees=@($others)+@($employee);Write-HopassJson $path $cfg
 $tokenFile=Join-Path ([Environment]::GetFolderPath('Desktop')) 'HOPASS-employee-token.txt';[IO.File]::WriteAllText($tokenFile,$token,[Text.UTF8Encoding]::new($false));$copied=$true;try{[Windows.Forms.Clipboard]::SetText($token)}catch{$copied=$false};Add-Content -LiteralPath $log -Value ([DateTime]::Now.ToString('s')+' employee registration completed: '+$selected.UserNo) -Encoding UTF8;$copyText=if($copied){'클립보드에도 복사했습니다.'}else{'원격 클립보드는 사용할 수 없어 파일에서 복사하세요.'};[void][Windows.Forms.MessageBox]::Show("직원: $($selected.Label)`n`n연결 토큰 저장 완료:`n$tokenFile`n`n$copyText",'HOPASS 직원 연결')
}catch{try{Add-Content -LiteralPath (Join-Path $Root 'logs\integration-ui.log') -Value ([DateTime]::Now.ToString('s')+' employee registration ERROR: '+$_.Exception.ToString()) -Encoding UTF8}catch{};[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'HOPASS 직원 연결 오류');exit 1}

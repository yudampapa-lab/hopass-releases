﻿$ErrorActionPreference='Stop'
function Assert-X86 {if([IntPtr]::Size -ne 4){throw 'HUGEN 데이터베이스 연동은 32비트 PowerShell에서 실행해야 합니다.'}}
function Open-HugenDb([string]$Path){
 $connectionString='Provider=Microsoft.Jet.OLEDB.4.0;Data Source='+$Path+';Mode=Share Deny None;'
 $lastError=$null
 for($attempt=0;$attempt -lt 20;$attempt++){
  $c=New-Object Data.OleDb.OleDbConnection($connectionString)
  try{$c.Open();return $c}catch{$lastError=$_.Exception;$c.Dispose();if($attempt -lt 19){Start-Sleep -Milliseconds 500}}
 }
 throw $lastError
}
function Add-DbParam($Command,[Data.OleDb.OleDbType]$Type,$Value,[int]$Size=0){$p=if($Size -gt 0){$Command.Parameters.Add('?',$Type,$Size)}else{$Command.Parameters.Add('?',$Type)};$p.Value=$Value;return $p}
function Read-HugenDevice([string]$Database){
 $c=Open-HugenDb $Database;try{$q=$c.CreateCommand();$q.CommandText='SELECT DeviceNo,DeviceName,DeviceTID,CommType,TCPAddress,TCPPort FROM tbDevice WHERE DeviceNo=?';[void](Add-DbParam $q ([Data.OleDb.OleDbType]::Integer) 14);$r=$q.ExecuteReader();try{if(!$r.Read()){throw 'HUGEN 장비 14를 찾을 수 없습니다.'};return [pscustomobject]@{deviceNo=[int]$r[0];deviceName=[string]$r[1];deviceTID=[int]$r[2];commType=[int]$r[3];tcpAddress=[string]$r[4];tcpPort=[int]$r[5]}}finally{$r.Dispose()}}finally{$c.Dispose()}
}
function Set-HugenDeviceEndpoint([string]$Database,[string]$Address,[int]$Port){
 $c=Open-HugenDb $Database;try{$tx=$c.BeginTransaction();try{$q=$c.CreateCommand();$q.Transaction=$tx;$q.CommandText='UPDATE tbDevice SET TCPAddress=?,TCPPort=? WHERE DeviceNo=? AND DeviceTID=?';[void](Add-DbParam $q ([Data.OleDb.OleDbType]::VarWChar) $Address 50);[void](Add-DbParam $q ([Data.OleDb.OleDbType]::Integer) $Port);[void](Add-DbParam $q ([Data.OleDb.OleDbType]::Integer) 14);[void](Add-DbParam $q ([Data.OleDb.OleDbType]::Integer) 1);if($q.ExecuteNonQuery() -ne 1){throw '장비 연결 설정 변경 대상이 정확히 1개가 아닙니다.'};$tx.Commit()}catch{$tx.Rollback();throw}finally{$tx.Dispose()}}finally{$c.Dispose()}
}
function Stop-Hugen([string]$Executable){
 $full=[IO.Path]::GetFullPath($Executable);$targets=@(Get-Process -Name 'Hugen' -ErrorAction SilentlyContinue|Where-Object{try{[IO.Path]::GetFullPath($_.Path) -eq $full}catch{$false}})
 foreach($p in $targets){[void]$p.CloseMainWindow()};$end=[DateTime]::UtcNow.AddSeconds(20);foreach($p in $targets){while(!$p.HasExited -and [DateTime]::UtcNow -lt $end){Start-Sleep -Milliseconds 250};if(!$p.HasExited){throw 'HUGEN이 실행 중입니다. 작업을 저장하고 HUGEN을 정상 종료한 뒤 다시 실행하세요.'}}
}
function Get-HugenDbLockers([string]$Database,[string]$Inspector){$json=& $Inspector $Database;if($LASTEXITCODE -ne 0){throw 'DB 잠금 프로세스 조회에 실패했습니다.'};return @($json|ConvertFrom-Json)}
function Stop-HugenDbLockers([string]$Database,[string]$HugenDirectory,[string]$Inspector){
 $base=[IO.Path]::GetFullPath($HugenDirectory).TrimEnd('\')+'\'
 for($attempt=0;$attempt -lt 3;$attempt++){
  $lockers=@(Get-HugenDbLockers $Database $Inspector);if($lockers.Count -eq 0){return @()}
  $owned=@();foreach($item in $lockers){try{$p=Get-Process -Id ([int]$item.pid) -ErrorAction Stop;$path=[IO.Path]::GetFullPath($p.Path);if($path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){$owned+=$p}}catch{}}
  foreach($p in $owned){[void]$p.CloseMainWindow()};$end=[DateTime]::UtcNow.AddSeconds(8);foreach($p in $owned){while(!$p.HasExited -and [DateTime]::UtcNow -lt $end){Start-Sleep -Milliseconds 200};if(!$p.HasExited){Stop-Process -Id $p.Id -Force}}
  Start-Sleep -Milliseconds 800
 }
 # 외부 프로그램이 파일을 사용한다는 사실만으로 차단하지 않는다. Jet 공유 모드로
 # 실제 접속을 시도해 동시 사용 가능 여부를 판단한다.
 return @(Get-HugenDbLockers $Database $Inspector)
}
function Start-Hugen([string]$Executable){Start-Process -FilePath $Executable -WorkingDirectory (Split-Path -Parent $Executable)|Out-Null}
function Set-HopassMode([string]$Root,[string]$Mode){
 $server=Read-HopassJson (Join-Path $Root 'server-config.json');$server.mode=$Mode;Write-HopassJson (Join-Path $Root 'server-config.json') $server
 $app=Read-HopassJson (Join-Path $Root 'data\config.json');$app.mode=$Mode;Write-HopassJson (Join-Path $Root 'data\config.json') $app
}
function New-Secret([int]$Bytes=32){$b=New-Object byte[] $Bytes;$rng=[Security.Cryptography.RandomNumberGenerator]::Create();try{$rng.GetBytes($b)}finally{$rng.Dispose()};return [Convert]::ToBase64String($b).TrimEnd('=').Replace('+','-').Replace('/','_')}

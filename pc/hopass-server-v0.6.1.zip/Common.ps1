﻿$ErrorActionPreference='Stop'
function Write-HopassJson([string]$Path,$Value){
 $parent=Split-Path -Parent $Path;New-Item -ItemType Directory -Path $parent -Force|Out-Null
 $tmp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 [IO.File]::WriteAllText($tmp,($Value|ConvertTo-Json -Depth 12),(New-Object Text.UTF8Encoding($false)))
 if(Test-Path -LiteralPath $Path){[IO.File]::Replace($tmp,$Path,[System.Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($tmp,$Path)}
}
function Read-HopassJson([string]$Path){Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json}
function Current-Release([string]$Root){
 $v=[string](Read-HopassJson (Join-Path $Root 'current.json')).version
 if($v -notmatch '^\d+\.\d+\.\d+$'){throw 'Invalid installed version'}
 return Join-Path $Root ('releases\'+$v)
}
function Hopass-Health([string]$Root){
 try{$cfg=Read-HopassJson (Join-Path $Root 'server-config.json');$expected=[string](Read-HopassJson (Join-Path $Root 'current.json')).version;$r=Invoke-RestMethod ('http://127.0.0.1:'+$cfg.port+'/health') -TimeoutSec 2;if($r.ok -ne $true -or $r.service -ne 'hopass' -or $r.mode -ne $cfg.mode -or [string]$r.version -ne $expected){return $false};if($cfg.mode -eq 'live-pilot'){$l=Invoke-RestMethod 'http://127.0.0.1:8790/health' -TimeoutSec 2;return $l.ok -eq $true};return $cfg.mode -eq 'simulation'}catch{return $false}
}
function Wait-HopassHealth([string]$Root,[int]$Seconds=20){$end=[DateTime]::UtcNow.AddSeconds($Seconds);do{if(Hopass-Health $Root){return $true};Start-Sleep -Milliseconds 400}while([DateTime]::UtcNow -lt $end);return $false}
function Stop-Hopass([string]$Root){
 $path=Join-Path $Root 'data\processes.json';$records=@();if(Test-Path -LiteralPath $path){$records=@(Read-HopassJson $path)}
 foreach($record in $records){
  try{$p=Get-Process -Id ([int]$record.id) -ErrorAction Stop
   if($p.StartTime.ToUniversalTime().Ticks.ToString() -eq $record.startTicks -and [IO.Path]::GetFullPath($p.Path) -eq [IO.Path]::GetFullPath((Join-Path $Root 'runtime\node.exe'))){$p.Kill();[void]$p.WaitForExit(5000)}
  }catch{}
 }
 Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
 # Recover from stale/missing process metadata by stopping only this install's bundled Node runtime.
 $runtime=[IO.Path]::GetFullPath((Join-Path $Root 'runtime\node.exe'))
 Get-Process node -ErrorAction SilentlyContinue|ForEach-Object{try{if([IO.Path]::GetFullPath($_.Path) -eq $runtime){$_.Kill();[void]$_.WaitForExit(5000)}}catch{}}
}
function Start-Hopass([string]$Root){
 $updatePath=Join-Path $Root 'update-config.json'
 if(Test-Path -LiteralPath $updatePath){
  $updateConfig=Read-HopassJson $updatePath
  if(([string]$updateConfig.manifest_url) -match '100\.117\.81\.117|:3220/'){
   Write-HopassJson $updatePath @{manifest_url='https://raw.githubusercontent.com/yudampapa-lab/hopass-releases/main/pc/manifest.json'}
  }
 }
 if(Hopass-Health $Root){return}
 Stop-Hopass $Root
 $release=Current-Release $Root;$node=Join-Path $Root 'runtime\node.exe';$cfg=Read-HopassJson (Join-Path $Root 'server-config.json')
 if($cfg.mode -notin @('simulation','live-pilot')){throw 'Invalid HOPASS mode'}
 if([int]$cfg.port -lt 1024 -or [int]$cfg.port -gt 65535){throw 'Invalid local port'}
 $env:ONPASS_DATA=Join-Path $Root 'data';$env:ONPASS_HOST='127.0.0.1';$env:ONPASS_PORT=[string]$cfg.port
 $env:HOPASS_VERSION=[string](Read-HopassJson (Join-Path $Root 'current.json')).version
 $relay=if($cfg.PSObject.Properties['relayUrl']){[string]$cfg.relayUrl}else{'https://hopass-relay.yudampapa.workers.dev'}
 $relayUri=[uri]$relay;if($relayUri.Scheme -ne 'https' -or !$relayUri.Host -or $relayUri.UserInfo -or $relayUri.Query -or $relayUri.Fragment){throw 'Invalid Cloudflare relay URL'}
 $env:ONPASS_SERVER=$relay.TrimEnd('/');$env:ONPASS_CREDENTIALS=Join-Path $Root 'data\pilot-credentials.json'
 New-Item -ItemType Directory -Path (Join-Path $Root 'logs') -Force|Out-Null
 if(!(Test-Path -LiteralPath (Join-Path $Root 'data\config.json'))){& $node (Join-Path $release 'server\init.mjs')|Out-Null;if($LASTEXITCODE -ne 0){throw 'Server initialization failed'}}
 $records=@()
 try{
  if($cfg.mode -eq 'live-pilot'){
   $liveConfig=Join-Path $Root 'data\hugen-live.json';if(!(Test-Path -LiteralPath $liveConfig)){throw 'HUGEN live configuration is missing'}
   $liveSettings=Read-HopassJson $liveConfig;if(!(Test-Path -LiteralPath ([string]$liveSettings.secretFile))){throw 'HUGEN live secret is missing'}
   $env:HOPASS_LIVE_CONFIG=$liveConfig;$env:HOPASS_LIVE_SECRET_FILE=[string]$liveSettings.secretFile
   $p=Start-Process -FilePath $node -ArgumentList ('"'+(Join-Path $release 'integration\hugen-live.mjs')+'"') -WorkingDirectory $release -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $Root 'logs\hugen-live.out.log') -RedirectStandardError (Join-Path $Root 'logs\hugen-live.err.log')
   $records+=@{id=$p.Id;startTicks=$p.StartTime.ToUniversalTime().Ticks.ToString();role='hugen-live'};Write-HopassJson (Join-Path $Root 'data\processes.json') $records
   $end=[DateTime]::UtcNow.AddSeconds(10);$ready=$false;do{try{$ready=(Invoke-RestMethod 'http://127.0.0.1:8790/health' -TimeoutSec 1).ok -eq $true}catch{};if(!$ready){Start-Sleep -Milliseconds 200}}while(!$ready -and [DateTime]::UtcNow -lt $end);if(!$ready){throw 'HUGEN local integration did not start'}
  }
  foreach($name in @('server','bridge')){
   $p=Start-Process -FilePath $node -ArgumentList ('"'+(Join-Path $release ('server\'+$name+'.mjs'))+'"') -WorkingDirectory $release -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $Root ('logs\'+$name+'.out.log')) -RedirectStandardError (Join-Path $Root ('logs\'+$name+'.err.log'))
   $records+=@{id=$p.Id;startTicks=$p.StartTime.ToUniversalTime().Ticks.ToString();role=$name}
   try{Write-HopassJson (Join-Path $Root 'data\processes.json') $records}catch{if(!$p.HasExited){$p.Kill();[void]$p.WaitForExit(5000)};throw}
  }
  if(!(Wait-HopassHealth $Root)){throw 'HOPASS health check failed. Check logs.'}
 }catch{Stop-Hopass $Root;throw}
}
function Test-FeedUri([uri]$Uri){
 if($Uri.UserInfo -or $Uri.Fragment){throw 'Invalid update URL'}
 if($Uri.Scheme -eq 'https'){return}
 $ip=$null;$isIp=[Net.IPAddress]::TryParse($Uri.Host,[ref]$ip)
 if($Uri.Scheme -eq 'http' -and $isIp){$b=$ip.GetAddressBytes();if([Net.IPAddress]::IsLoopback($ip) -or ($b.Length -eq 4 -and $b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127)){return}}
 throw 'GitHub HTTPS 업데이트 주소만 사용할 수 있습니다.'
}
function Download-Hopass([uri]$Uri,[string]$Path,[int]$MaxBytes=33554432){
 Test-FeedUri $Uri
 $req=[Net.HttpWebRequest]::Create($Uri);$req.AllowAutoRedirect=$false;$req.Timeout=15000;$req.ReadWriteTimeout=15000
 $res=$req.GetResponse();try{
  if([int]$res.StatusCode -ne 200){throw 'Update download did not return 200'}
  $inputStream=$res.GetResponseStream();$out=[IO.File]::Create($Path)
  try{$buffer=New-Object byte[] 8192;$size=0;while(($n=$inputStream.Read($buffer,0,$buffer.Length)) -gt 0){$size+=$n;if($size -gt $MaxBytes){throw 'Update too large'};$out.Write($buffer,0,$n)}}finally{$out.Dispose();$inputStream.Dispose()}
 }finally{$res.Close()}
}
function Expand-HopassPackage([string]$Zip,[string]$Destination){
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $base=[IO.Path]::GetFullPath($Destination).TrimEnd('\')+'\';New-Item -ItemType Directory -Path $base -Force|Out-Null
 $archive=[IO.Compression.ZipFile]::OpenRead($Zip);$seen=@{};$size=0
 try{foreach($entry in $archive.Entries){
  $n=$entry.FullName.Replace('/','\');$parts=$n.Split('\')
  if(!$n -or $n.Contains(':') -or $n.StartsWith('\') -or $parts -contains '..' -or $parts -contains '.' -or $n -match '[ .](\\|$)'){throw 'Unsafe ZIP entry'}
  $dest=[IO.Path]::GetFullPath((Join-Path $base $n));if(!$dest.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'ZIP path escapes destination'}
  if($seen.ContainsKey($dest.ToLowerInvariant())){throw 'Duplicate ZIP path'};$seen[$dest.ToLowerInvariant()]=$true
  $size+=$entry.Length;if($size -gt 67108864){throw 'Expanded package too large'}
  if($n.EndsWith('\')){New-Item -ItemType Directory -Path $dest -Force|Out-Null;continue}
  New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
  [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$dest,$false)
 }}finally{$archive.Dispose()}
}

function Hopass-Sha256([string]$Path){$stream=[IO.File]::OpenRead($Path);$hash=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$hash.Dispose()}}

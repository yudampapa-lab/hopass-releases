﻿#Requires -Version 5.1
param([string]$OutputRoot,[switch]$NoUI)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Connection-Parser.ps1"
$target=Get-Content -LiteralPath "$PSScriptRoot\operating-target.json" -Raw|ConvertFrom-Json
if($target.deviceNo -ne 14 -or $target.address -ne '192.168.10.114' -or $target.port -ne 5001){throw 'Target configuration differs from the verified diagnostic report.'}
if(!$OutputRoot){$OutputRoot=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'HOPASS\Diagnostics'}
$run=Join-Path $OutputRoot ('link-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $run -Force|Out-Null
$report=[ordered]@{app='HOPASS';createdAt=[DateTimeOffset]::Now.ToString('o');computerName=$env:COMPUTERNAME;expectedComputer=$target.computerName;correctComputer=($env:COMPUTERNAME -eq $target.computerName);target=$target;inspection='existing TCP connection table only';newDeviceConnectionCreated=$false;deviceCommandSent=$false;databaseRecordsWritten=$false;connections=@();hugenEstablished=$false;errors=@()}
try{
 if(!$report.correctComputer){throw '진단 JSON을 생성한 운영 PC에서 실행해야 합니다.'}
 $lines=@(& "$env:SystemRoot\System32\netstat.exe" -ano -p TCP)
 if($LASTEXITCODE -ne 0){throw '기존 연결 목록을 읽지 못했습니다.'}
 $rows=@(Convert-HOPASSNetstat -Lines $lines -TargetAddress $target.address -TargetPort $target.port)
 foreach($row in $rows){
  $name=$null
  try{$name=(Get-Process -Id $row.processId -ErrorAction Stop).ProcessName}catch{}
  $report.connections+=([pscustomobject]@{localEndpoint=$row.localEndpoint;remoteEndpoint=$row.remoteEndpoint;state=$row.state;processId=$row.processId;processName=$name})
  if($name -eq 'Hugen' -and $row.state -eq 'ESTABLISHED'){$report.hugenEstablished=$true}
 }
}catch{$report.errors+=($_.Exception.Message)}
$path=Join-Path $run 'HOPASS-link-check.json'
$report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $path -Encoding UTF8
$status=if($report.errors.Count){'확인이 필요합니다: '+($report.errors -join ' / ')}elseif($report.hugenEstablished){'HUGEN과 장비 사이의 기존 TCP 연결을 확인했습니다.'}else{'HUGEN의 연결된 TCP 세션을 확인하지 못했습니다. 이 결과만으로 장비 고장이나 연결 불가를 뜻하지는 않습니다.'}
$summary=@"
HOPASS 운영 PC 연결 확인

$status
대상: 2층 사무실(도서관) / 192.168.10.114:5001
HUGEN TCP 연결 확인: $($report.hugenEstablished)
읽은 시각: $($report.createdAt)

기존 연결 목록만 읽었습니다. 새 장비 접속, 문 개방, DB 변경은 하지 않았습니다.
TCP 연결 존재는 실제 문 열림이나 출입기록 저장 검증을 의미하지 않습니다.

결과 파일: $path
"@
$summary|Set-Content -LiteralPath (Join-Path $run 'RESULT.txt') -Encoding UTF8
Write-Output $summary
if(!$NoUI){Add-Type -AssemblyName System.Windows.Forms;[void][System.Windows.Forms.MessageBox]::Show($summary,'HOPASS 연결 확인');Start-Process -FilePath 'explorer.exe' -ArgumentList ('"'+$run+'"')}
if($report.errors.Count){exit 1}

import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import {randomBytes} from 'node:crypto';

const page=readFileSync(new URL('./admin.html',import.meta.url),'utf8');

function save(path,value){const temp=path+'.tmp';writeFileSync(temp,JSON.stringify(value,null,2),{mode:0o600});renameSync(temp,path)}
async function requestBody(req){let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>16384)throw Object.assign(Error('body_too_large'),{code:413})}try{return JSON.parse(text)}catch{throw Object.assign(Error('invalid_json'),{code:400})}}
export function createAdmin({configPath,credentialsPath,relayBase,hash}){
 async function cloud(path,method='GET',body){const credentials=JSON.parse(readFileSync(credentialsPath));const headers={authorization:`Bearer ${credentials.bridgeToken}`,'content-type':'application/json'};const response=await fetch(relayBase+path,{method,headers,redirect:'error',body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(8000)});const value=await response.json();if(!response.ok)throw Object.assign(Error(value.error||('cloud_http_'+response.status)),{code:response.status});return value}
 return async function(req,res,path){
  const send=(code,value,type='application/json; charset=utf-8')=>{res.writeHead(code,{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'});res.end(type.startsWith('application/json')?JSON.stringify(value):value)};
  try{
   if(path==='/admin'&&req.method==='GET'){send(200,page,'text/html; charset=utf-8');return true}
   if(path==='/v1/admin/rebind'&&req.method==='POST'){const b=await requestBody(req),credentials=JSON.parse(readFileSync(credentialsPath));const response=await fetch(relayBase+'/v1/admin/rebind',{method:'POST',headers:{'x-hopass-recovery-code':String(b.code||''),'content-type':'application/json'},redirect:'error',body:JSON.stringify({bridgeToken:credentials.bridgeToken}),signal:AbortSignal.timeout(8000)});const value=await response.json();if(!response.ok)throw Object.assign(Error(value.error||('cloud_http_'+response.status)),{code:response.status});send(200,value);return true}
   if(path==='/v1/admin/config'&&req.method==='GET'){send(200,await cloud('/v1/bridge/admin/config'));return true}
   if(path==='/v1/admin/doors'&&req.method==='POST'){const b=await requestBody(req);await cloud('/v1/bridge/admin/doors','POST',b);const cfg=JSON.parse(readFileSync(configPath)),door={id:b.id,name:b.name,enabled:b.enabled===true,hugen:{deviceNo:b.deviceNo,deviceTID:b.deviceTID,commType:2,tcpPort:5001,verifiedOnLivePC:false},beacon:{uuid:String(b.uuid).toLowerCase(),major:b.major,minor:b.minor}};cfg.doors=[...cfg.doors.filter(d=>d.id!==b.id),door];save(configPath,cfg);send(200,{ok:true});return true}
   if(path==='/v1/admin/employees'&&req.method==='POST'){const b=await requestBody(req),token=randomBytes(32).toString('base64url');await cloud('/v1/bridge/admin/employees','POST',{...b,token});const cfg=JSON.parse(readFileSync(configPath)),employee={id:b.id,name:b.name,enabled:b.enabled!==false,tokenHash:hash(token),doors:b.doorIds};cfg.employees=[...cfg.employees.filter(e=>e.id!==b.id),employee];save(configPath,cfg);send(200,{ok:true,token});return true}
   return false;
  }catch(e){send(e.code||500,{error:e.message||'admin_error'});return true}
 }
}

﻿param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop';. (Join-Path (Split-Path -Parent $PSScriptRoot) 'Common.ps1');Add-Type -AssemblyName System.Windows.Forms
$url='https://hopass-relay.yudampapa.workers.dev'
try{
 $cfg=Read-HopassJson (Join-Path $Root 'server-config.json')
 foreach($name in @('relayUrl','publicUrl')){if($cfg.PSObject.Properties[$name]){$cfg.$name=$url}else{$cfg|Add-Member -NotePropertyName $name -NotePropertyValue $url}}
 Write-HopassJson (Join-Path $Root 'server-config.json') $cfg
 Write-HopassJson (Join-Path $Root 'data\mobile-access.json') @{url=$url;mode='cloudflare-worker';configuredAt=[DateTime]::UtcNow.ToString('o')}
 $urlFile=Join-Path ([Environment]::GetFolderPath('Desktop')) 'HOPASS-server-url.txt';[IO.File]::WriteAllText($urlFile,$url,[Text.UTF8Encoding]::new($false))
 Stop-Hopass $Root;Start-Hopass $Root
 $copied=$true;try{[Windows.Forms.Clipboard]::SetText($url)}catch{$copied=$false};$copyText=if($copied){'주소를 클립보드에도 복사했습니다.'}else{'주소는 바탕화면 파일에서 복사할 수 있습니다.'}
 [void][Windows.Forms.MessageBox]::Show("Cloudflare 중계 서버 연결을 적용했습니다.`n$url`n`nHOPASS 서버를 자동 재시작했습니다.`n$copyText",'HOPASS Cloudflare 연결')
}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'HOPASS Cloudflare 연결 오류');exit 1}

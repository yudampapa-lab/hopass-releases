﻿param([Parameter(Mandatory=$true)][string]$Root,[string]$HugenDirectory='C:\HUGEN')
$admin=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent());if(!$admin.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){$ps=Join-Path $env:SystemRoot 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe';if(!(Test-Path $ps)){$ps='powershell.exe'};$args='-NoProfile -STA -ExecutionPolicy Bypass -File "'+$MyInvocation.MyCommand.Path+'" -Root "'+$Root+'" -HugenDirectory "'+$HugenDirectory+'"';try{$p=Start-Process -FilePath $ps -Verb RunAs -ArgumentList $args -PassThru -Wait;exit $p.ExitCode}catch{exit 1}}
$ErrorActionPreference='Stop';. (Join-Path $PSScriptRoot 'Integration-Common.ps1');. (Join-Path (Split-Path -Parent $PSScriptRoot) 'Common.ps1');Assert-X86;Add-Type -AssemblyName System.Windows.Forms
try{
 $db=Join-Path $HugenDirectory 'HugenData.mdb';$exe=Join-Path $HugenDirectory 'Hugen.exe';$originalPath=Join-Path $Root 'data\hugen-original.json';if(!(Test-Path -LiteralPath $originalPath)){throw '저장된 원래 HUGEN 연결 설정이 없습니다.'};$original=Read-HopassJson $originalPath
 Stop-Hopass $Root;Stop-Hugen $exe;$device=Read-HugenDevice $db;if($device.tcpAddress -ne '127.0.0.1' -or $device.tcpPort -ne 15001){throw '장비 14가 HOPASS 프록시를 가리키지 않아 변경하지 않았습니다.'}
 Set-HugenDeviceEndpoint $db ([string]$original.tcpAddress) ([int]$original.tcpPort);Set-HopassMode $Root 'simulation';Start-Hugen $exe;Start-Hopass $Root
 [void][Windows.Forms.MessageBox]::Show("실제 연동을 해제하고 원래 연결을 복구했습니다.`n장비 14: $($original.tcpAddress):$($original.tcpPort)",'HOPASS')
}catch{try{Start-Hugen $exe}catch{};[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'HOPASS 연동 해제 오류');exit 1}

// Derived from Hugen Access Control 21.1.18.1 IL. No socket or DB operations.
// Device response checksum convention is provisional until a real frame is captured.
export function encodeTransientOpen(tid){
 if(!Number.isInteger(tid)||tid<1||tid>255)throw Error('A specific terminal TID (1..255) is required');
 const b=Buffer.from([0x06,0x02,0,8,tid,0x38,0,0x03]);
 b[6]=b.subarray(0,6).reduce((sum,n)=>(sum+n)&255,0);return b;
}
export function decodeResponse(frame,{expectedTid,expectedCommand=0x38}={}){
 if(!Buffer.isBuffer(frame)||frame.length<9||frame.length>1024)throw Error('invalid frame size');
 if(frame[0]!==0x08||frame[1]!==0x04||frame.at(-1)!==0x03)throw Error('invalid frame markers');
 if(frame.readUInt16BE(2)!==frame.length)throw Error('frame length mismatch');
 if(frame[4]!==expectedTid||frame[5]!==expectedCommand)throw Error('response does not match request');
 const checksum=frame.subarray(0,-2).reduce((sum,n)=>(sum+n)&255,0);
 if(checksum!==frame.at(-2))throw Error('unverified or invalid checksum');
 return {terminalId:frame[4],command:frame[5],responseCode:frame[6],payload:Buffer.from(frame.subarray(7,-2)),transportFrameValid:true,physicalDoorOpenConfirmed:false,hugenRecorded:false};
}
export class ResponseBuffer{
 constructor(){this.buffer=Buffer.alloc(0);}
 push(chunk){
  if(!Buffer.isBuffer(chunk))throw Error('buffer required');
  if(this.buffer.length+chunk.length>4096){this.buffer=Buffer.alloc(0);throw Error('receive buffer overflow');}
  this.buffer=Buffer.concat([this.buffer,chunk]);const out=[];
  while(this.buffer.length>=4){
   if(this.buffer[0]!==8||this.buffer[1]!==4){this.buffer=Buffer.alloc(0);throw Error('invalid stream prefix');}
   const length=this.buffer.readUInt16BE(2);if(length<9||length>1024){this.buffer=Buffer.alloc(0);throw Error('invalid stream length');}
   if(this.buffer.length<length)break;out.push(Buffer.from(this.buffer.subarray(0,length)));this.buffer=this.buffer.subarray(length);
  }return out;
 }
}

import http from 'node:http';
import {createHash,randomUUID,timingSafeEqual} from 'node:crypto';
import {readFileSync,mkdirSync,appendFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {setDefaultResultOrder} from 'node:dns';
import {createAdmin} from './admin.mjs';
setDefaultResultOrder('ipv4first');

export const hash=v=>createHash('sha256').update(v).digest('hex');
const equal=(a,b)=>typeof b==='string'&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
export function makeServer({dataDir,clock=Date.now,cooldownMs=30000}){
 mkdirSync(dataDir,{recursive:true});const configPath=resolve(dataDir,'config.json'),auditPath=resolve(dataDir,'events.jsonl');
 const credentialsPath=process.env.ONPASS_CREDENTIALS||resolve(dataDir,'pilot-credentials.json'),relayBase=(process.env.ONPASS_SERVER||'http://127.0.0.1:8787').replace(/\/$/,'');
 const admin=createAdmin({configPath,credentialsPath,relayBase,hash});
 let config=JSON.parse(readFileSync(configPath));if(!['simulation','live-pilot'].includes(config.mode))throw Error('Unsupported HOPASS mode.');
 const requests=new Map(),last=new Map();let bridgeSeen=0,hugenConnected=false,controllerConnected=false,bridgeLastEvent='BRIDGE_NOT_SEEN';
 // Reconstruct request IDs on restart. Interrupted requests expire, never replay to a door.
 if(existsSync(auditPath))for(const line of readFileSync(auditPath,'utf8').split('\n').filter(Boolean)){
  const e=JSON.parse(line);if(e.request)requests.set(e.request.id,e.request);
 }
 const audit=request=>appendFileSync(auditPath,JSON.stringify({at:clock(),request})+'\n',{mode:0o600});
 for(const r of requests.values())if(r.status==='PENDING'){r.status='EXPIRED';r.reason='server_restart';audit(r);}
 function expire(){for(const r of requests.values())if(r.status==='PENDING'&&r.expiresAt<=clock()){r.status='EXPIRED';r.reason='deadline';audit(r);}}
 function auth(req,bridge=false){
  config=JSON.parse(readFileSync(configPath));if(!['simulation','live-pilot'].includes(config.mode))throw Object.assign(Error('unsupported_mode'),{code:503});
  const token=/^Bearer ([A-Za-z0-9_-]{40,100})$/.exec(req.headers.authorization||'')?.[1];if(!token)return null;
  const h=hash(token);return bridge?equal(h,config.bridgeTokenHash):config.employees.find(e=>e.enabled&&equal(h,e.tokenHash));
 }
 const send=(res,code,value)=>{res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(value));};
 async function body(req){let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>8192)throw Object.assign(Error('body_too_large'),{code:413});}try{return JSON.parse(text);}catch{throw Object.assign(Error('invalid_json'),{code:400});}}
 const server=http.createServer(async(req,res)=>{try{
  const path=new URL(req.url,'http://localhost').pathname;
  if(path==='/health'&&req.method==='GET')return send(res,200,{ok:true,service:'hopass',version:process.env.HOPASS_VERSION||'0.4.0',mode:config.mode,bridgeOnline:clock()-bridgeSeen<5000,hugenConnected:config.mode==='live-pilot'&&clock()-bridgeSeen<5000&&hugenConnected,controllerConnected:config.mode==='live-pilot'&&clock()-bridgeSeen<5000&&controllerConnected,bridgeLastEvent});
  if(path==='/admin'||path.startsWith('/v1/admin/')){await admin(req,res,path);return}
  const isBridge=path.startsWith('/v1/bridge/'),actor=auth(req,isBridge);
  if(!actor)return send(res,401,{error:'unauthorized'});expire();
  if(path==='/v1/bridge/status'&&req.method==='POST'){
   const b=await body(req);bridgeSeen=clock();hugenConnected=config.mode==='live-pilot'&&b.hugenConnected===true;controllerConnected=config.mode==='live-pilot'&&b.controllerConnected===true;bridgeLastEvent=typeof b.lastEvent==='string'?b.lastEvent.slice(0,180):'';return send(res,200,{ok:true});
  }
  if(path==='/v1/bridge/commands'&&req.method==='GET'){
    bridgeSeen=clock();const commands=[];
   for(const r of requests.values())if(r.status==='PENDING'&&!r.dispatched){
    const employee=config.employees.find(e=>e.id===r.employeeId&&e.enabled&&e.doors.includes(r.doorId));
    if(!employee||!config.doors.some(d=>d.id===r.doorId&&d.enabled)){r.status='DENIED';r.reason='permission_revoked';audit(r);continue;}
    r.dispatched=true;audit(r);commands.push({id:r.id,doorId:r.doorId,employeeId:r.employeeId,expiresAt:r.expiresAt,mode:config.mode});
   }
   return send(res,200,{mode:config.mode,commands});
  }
  if(path==='/v1/bridge/results'&&req.method==='POST'){
   const b=await body(req);expire();const r=requests.get(b.id);
   if(!r)return send(res,404,{error:'unknown_request'});
   const allowed=config.mode==='simulation'?['SIMULATED']:['OPENED_RECORDED','OPENED_LOG_FAILED','DEVICE_REJECTED','DEVICE_UNAVAILABLE'];
   if(!allowed.includes(b.status))return send(res,400,{error:'result_not_allowed_for_mode'});
   if(r.status!=='PENDING'||!r.dispatched)return send(res,409,{error:'not_pending'});
   r.status=b.status;r.completedAt=clock();r.hugenRecorded=b.status==='OPENED_RECORDED';r.detail=typeof b.detail==='string'?b.detail.slice(0,300):'';audit(r);return send(res,200,r);
  }
  if(isBridge)return send(res,404,{error:'not_found'});
  if(path==='/v1/me'&&req.method==='GET')return send(res,200,{id:actor.id,name:actor.name,mode:config.mode,doors:config.doors.filter(d=>actor.doors.includes(d.id)),hugenConnected:config.mode==='live-pilot'&&clock()-bridgeSeen<5000&&hugenConnected,bridgeOnline:clock()-bridgeSeen<5000});
  if(path==='/v1/access-requests'&&req.method==='POST'){
   const b=await body(req);if(typeof b.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(b.requestId))return send(res,400,{error:'invalid_request_id'});
   const old=requests.get(b.requestId);if(old){if(old.employeeId!==actor.id||old.doorId!==b.doorId)return send(res,409,{error:'request_id_conflict'});return send(res,200,old);}
   const door=config.doors.find(d=>d.id===b.doorId&&d.enabled);
   if(!door||!actor.doors.includes(door.id))return send(res,403,{error:'door_not_authorized'});
   if(b.source!=='beacon'||b.beacon?.uuid?.toLowerCase()!==door.beacon.uuid||b.beacon?.major!==door.beacon.major||b.beacon?.minor!==door.beacon.minor)return send(res,400,{error:'beacon_mismatch'});
   if(!Number.isFinite(b.observedAt)||Math.abs(clock()-b.observedAt)>10000||!Number.isFinite(b.rssi)||b.rssi>=0||b.rssi< -120)return send(res,400,{error:'invalid_observation'});
   const key=actor.id+':'+door.id;if(last.has(key)&&clock()-last.get(key)<cooldownMs)return send(res,429,{error:'cooldown'});
   const r={id:b.requestId,employeeId:actor.id,doorId:door.id,source:'beacon',status:'PENDING',mode:config.mode,createdAt:clock(),expiresAt:clock()+10000,hugenRecorded:false};
   audit(r);requests.set(r.id,r);last.set(key,clock());return send(res,202,r);
  }
  if(path==='/v1/events'&&req.method==='GET')return send(res,200,{events:[...requests.values()].filter(r=>r.employeeId===actor.id).slice(-50).reverse()});
  if(path.startsWith('/v1/access-requests/')&&req.method==='GET'){
   const r=requests.get(path.split('/').pop());if(!r||r.employeeId!==actor.id)return send(res,404,{error:'not_found'});return send(res,200,r);
  }
  send(res,404,{error:'not_found'});
 }catch(e){if(!res.headersSent)send(res,e.code||500,{error:e.code?e.message:'server_error'});else res.destroy();}});
 server.requestTimeout=10000;server.headersTimeout=10000;
 return server;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const dir=resolve(process.env.ONPASS_DATA||fileURLToPath(new URL('./data',import.meta.url)));
 const server=makeServer({dataDir:dir});const host=process.env.ONPASS_HOST||'127.0.0.1',port=Number(process.env.ONPASS_PORT||8787);
 server.listen(port,host,()=>console.log(`HOPASS listening at http://${host}:${port}`));
}

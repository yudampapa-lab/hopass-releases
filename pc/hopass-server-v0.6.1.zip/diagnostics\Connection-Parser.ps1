﻿function Convert-HOPASSNetstat {
 param([string[]]$Lines,[string]$TargetAddress,[int]$TargetPort)
 $endpoint=$TargetAddress+':'+$TargetPort
 foreach($line in $Lines){
  if($line -match '^\s*TCP\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)\s*$'){
   if($Matches[2] -eq $endpoint){
    [pscustomobject]@{localEndpoint=$Matches[1];remoteEndpoint=$Matches[2];state=$Matches[3];processId=[int]$Matches[4]}
   }
  }
 }
}

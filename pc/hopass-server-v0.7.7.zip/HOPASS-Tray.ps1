﻿param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Common.ps1"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$created=$false;$mutex=New-Object Threading.Mutex($true,'HOPASS.Tray.CurrentUser',[ref]$created)
if(!$created){exit}
$script:paused=$false;$script:updateProcess=$null;$script:pending='';$script:lastNotice='';$script:lastError='';$script:failures=0
$form=New-Object Windows.Forms.Form;$form.ShowInTaskbar=$false;$form.WindowState='Minimized';$form.Opacity=0
$tray=New-Object Windows.Forms.NotifyIcon;$tray.Text='HOPASS · 서버 준비 중'
$bitmap=New-Object Drawing.Bitmap(32,32);$g=[Drawing.Graphics]::FromImage($bitmap);$g.Clear([Drawing.Color]::FromArgb(13,36,43));$font=New-Object Drawing.Font('Segoe UI',21,[Drawing.FontStyle]::Bold);$brush=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(99,229,193));$g.DrawString('H',$font,$brush,-1,-3);$tray.Icon=[Drawing.Icon]::FromHandle($bitmap.GetHicon());$g.Dispose();$font.Dispose();$brush.Dispose()
$menu=New-Object Windows.Forms.ContextMenuStrip
function Item([string]$Text,$Action){$item=New-Object Windows.Forms.ToolStripMenuItem($Text);if($Action){$item.add_Click($Action)};[void]$menu.Items.Add($item);return $item}
function Info([string]$Text){[void][Windows.Forms.MessageBox]::Show($Text,'HOPASS')}
function Run-Integration([string]$Script){try{$ps=Join-Path $env:SystemRoot 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe';if(!(Test-Path $ps)){$ps='powershell.exe'};$path=Join-Path (Current-Release $Root) ('integration\'+$Script);if(!(Test-Path -LiteralPath $path)){throw ('설정 파일이 없습니다: '+$Script)};Start-Process -FilePath $ps -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -File "'+$path+'" -Root "'+$Root+'"') -WindowStyle Normal|Out-Null}catch{Info $_.Exception.Message}}
function Run-Update([switch]$Install){
 if($script:updateProcess -and !$script:updateProcess.HasExited){return}
 $arg='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path (Current-Release $Root) 'Update.ps1')+'" -Root "'+$Root+'"'
 if(!$Install){$arg+=' -CheckOnly'}
 $script:updateProcess=Start-Process powershell.exe -ArgumentList $arg -WindowStyle Hidden -PassThru
 $update.Enabled=$false
}
function Show-Status {
 $version=(Read-HopassJson (Join-Path $Root 'current.json')).version
 $cfg=Read-HopassJson (Join-Path $Root 'server-config.json');$healthy=Hopass-Health $Root;$mode=if($cfg.mode -eq 'live-pilot'){'실제 연동'}else{'모의 모드'};$server=if($healthy){'실행 중'}else{'중지 / 확인 필요'};$link='해당 없음';if($cfg.mode -eq 'live-pilot'){try{$h=Invoke-RestMethod 'http://127.0.0.1:8790/health' -TimeoutSec 2;$link=if($h.hugenConnected){'HUGEN 및 장비 연결됨'}else{'HUGEN 연결 대기'}}catch{$link='연동 프로세스 확인 필요'}}
 $publicUrl=if($cfg.PSObject.Properties['relayUrl']){[string]$cfg.relayUrl}else{'https://hopass-relay.yudampapa.workers.dev'}
 $cloud=if(!$publicUrl){'공개 주소 설정 필요'}else{try{$rh=Invoke-RestMethod ($publicUrl.TrimEnd('/')+'/health') -TimeoutSec 4;if($rh.ok){'외부 공개 연결됨'}else{'외부 응답 오류'}}catch{'외부 연결 안 됨'}}
 Info "HOPASS $version`n로컬: $server / $mode`n외부: $cloud`n연결: $link`nHUGEN 매핑: 7개 출입구`n등록 비콘: 7곳`n`n설치: $Root`n$script:lastError"
}
$status=Item 'HOPASS · 준비 중' {Show-Status}
[void](Item '상태 보기' {Show-Status})
[void](Item '출입관리 페이지 열기' {try{Start-Hopass $Root;Start-Process 'http://127.0.0.1:8787/admin'}catch{Info $_.Exception.Message}})
[void](Item 'Tailscale 관리자 링크 열기 · 복사' {try{Start-Hopass $Root;$url=Enable-HopassAdminServe $Root;if(!$url){throw 'Tailscale이 설치되었는지 확인하세요.'};[Windows.Forms.Clipboard]::SetText($url);Start-Process $url;Info ("관리자 링크를 열고 복사했습니다.`n`n"+$url)}catch{Info $_.Exception.Message}})
$pause=Item '서버 일시 중지' {try{if($script:paused){Start-Hopass $Root;$script:paused=$false;$pause.Text='서버 일시 중지'}else{Stop-Hopass $Root;$script:paused=$true;$pause.Text='서버 시작'}}catch{Info $_.Exception.Message}}
[void](Item '서버 재시작' {try{Stop-Hopass $Root;Start-Hopass $Root;$script:paused=$false;$pause.Text='서버 일시 중지'}catch{Info $_.Exception.Message}})
[void]$menu.Items.Add((New-Object Windows.Forms.ToolStripSeparator))
[void](Item 'HUGEN 설정 진단' {$scriptPath=Join-Path (Current-Release $Root) 'diagnostics\Diagnose-HOPASS.ps1';$ps=Join-Path $env:SystemRoot 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe';if(!(Test-Path $ps)){$ps='powershell.exe'};Start-Process $ps -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -File "'+$scriptPath+'"') -WindowStyle Hidden})
[void](Item 'HUGEN 자동 실행 · 로그인 설정' {try{$keeper=Join-Path (Current-Release $Root) 'integration\HugenKeeper.exe';if(!(Test-Path -LiteralPath $keeper)){throw '현재 버전에는 HUGEN 자동 실행 기능이 없습니다.'};$p=Start-Process -FilePath $keeper -ArgumentList ('--configure --root "'+$Root+'"') -WindowStyle Normal -PassThru;$p.WaitForExit();Invoke-HugenKeeper $Root}catch{Info $_.Exception.Message}})
[void](Item '기존 장비 연결 확인' {Start-Process powershell.exe -ArgumentList ('-NoProfile -STA -ExecutionPolicy Bypass -File "'+(Join-Path (Current-Release $Root) 'diagnostics\Check-HOPASS-Link.ps1')+'"') -WindowStyle Hidden})
[void](Item '직원 연결 등록' {Run-Integration 'Register-Employee.ps1'})
[void](Item 'Cloudflare 연결 확인 · 주소 복사' {Run-Integration 'Configure-MobileAccess.ps1'})
[void](Item 'HUGEN 실제 연동 활성화' {Run-Integration 'Enable-HugenIntegration.ps1'})
[void](Item 'HUGEN 실제 연동 해제' {Run-Integration 'Disable-HugenIntegration.ps1'})
[void](Item '2층 도서관 문 1회 열림 시험' {Run-Integration 'Test-Door.ps1'})
[void](Item '로그 / 결과 폴더 열기' {Start-Process explorer.exe -ArgumentList ('"'+(Join-Path $Root 'logs')+'"')})
[void]$menu.Items.Add((New-Object Windows.Forms.ToolStripSeparator))
$update=Item '업데이트 확인' {try{if($script:pending){Run-Update -Install}else{Run-Update}}catch{Info $_.Exception.Message}}
[void](Item '업데이트 결과 보기' {try{$s=Read-HopassJson (Join-Path $Root 'update-status.json');Info ($s.message+"`n현재: "+$s.currentVersion+"`n새 버전: "+$s.availableVersion)}catch{Info '아직 업데이트 결과가 없습니다.'}})
[void](Item '업데이트 서버 설정' {Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $Root 'update-config.json')+'"')})
[void]$menu.Items.Add((New-Object Windows.Forms.ToolStripSeparator))
[void](Item '서버 종료' {$script:paused=$true;Stop-Hopass $Root;$tray.Visible=$false;$form.Close()})
$tray.ContextMenuStrip=$menu;$tray.Visible=$true;$tray.add_DoubleClick({Show-Status})
$tray.add_BalloonTipClicked({if($script:pending){Run-Update -Install}})
$heartbeat=Join-Path $Root 'data\tray-heartbeat.json'
$timer=New-Object Windows.Forms.Timer;$timer.Interval=3000
$timer.add_Tick({
 try{
  if(Test-Path -LiteralPath (Join-Path $Root '.update-stop')){Stop-Hopass $Root;$tray.Visible=$false;$form.Close();return}
  Write-HopassJson $heartbeat @{pid=$PID;updatedAt=[DateTime]::UtcNow.ToString('o')}
  Invoke-HugenKeeper $Root
  $healthy=Hopass-Health $Root;$mode=(Read-HopassJson (Join-Path $Root 'server-config.json')).mode;$status.Text=if($healthy -and $mode -eq 'live-pilot'){'HOPASS · HUGEN 실제 연동 중'}elseif($healthy){'HOPASS · 모의 서버 실행 중'}elseif($script:paused){'HOPASS · 일시 중지'}else{'HOPASS · 서버 확인 필요'};$tray.Text=$status.Text
  if(!$script:paused -and !$healthy){$script:failures++;if($script:failures -ge 3){try{Start-Hopass $Root;$script:lastError=''}catch{$script:lastError=$_.Exception.Message};$script:failures=0}}else{$script:failures=0}
  if($script:updateProcess -and $script:updateProcess.HasExited){$script:updateProcess.Dispose();$script:updateProcess=$null;$update.Enabled=$true
   $s=Read-HopassJson (Join-Path $Root 'update-status.json');if($s.state -eq 'available'){$script:pending=[string]$s.availableVersion;$update.Text='업데이트 설치 ('+$script:pending+')';if($script:lastNotice -ne $script:pending){$script:lastNotice=$script:pending;$tray.ShowBalloonTip(8000,'HOPASS 업데이트',$s.message,[Windows.Forms.ToolTipIcon]::Info)}}else{$script:pending='';$update.Text='업데이트 확인';if($s.state -eq 'error'){$tray.ShowBalloonTip(5000,'HOPASS 업데이트 확인',$s.message,[Windows.Forms.ToolTipIcon]::Warning)}}
  }
 }catch{$script:lastError=$_.Exception.Message}
})
$updateTimer=New-Object Windows.Forms.Timer;$updateTimer.Interval=15000;$updateTimer.add_Tick({$updateTimer.Interval=1800000;try{Run-Update}catch{}})
try{
 try{Start-Hopass $Root}catch{$script:lastError=$_.Exception.Message}
 Write-HopassJson $heartbeat @{pid=$PID;updatedAt=[DateTime]::UtcNow.ToString('o')}
 $timer.Start();$updateTimer.Start();$tray.ShowBalloonTip(5000,'HOPASS 서버','외부 중계 서버와 HUGEN 실제 연동을 관리합니다.',[Windows.Forms.ToolTipIcon]::Info)
 [Windows.Forms.Application]::Run($form)
}finally{$timer.Stop();$updateTimer.Stop();Stop-Hopass $Root;Remove-Item -LiteralPath $heartbeat -Force -ErrorAction SilentlyContinue;$tray.Visible=$false;$tray.Dispose();$bitmap.Dispose();$mutex.ReleaseMutex();$mutex.Dispose()}

﻿param([Parameter(Mandatory=$true)][string]$Root,[switch]$CheckOnly,[switch]$Headless)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Common.ps1"
$Root=[IO.Path]::GetFullPath($Root)
$created=$false;$mutex=New-Object Threading.Mutex($true,'HOPASS.Update.CurrentUser',[ref]$created)
if(!$created){exit 0}
$current='';$available='';$switched=$false;$stopped=$false;$oldPointer=$null
function Status([string]$State,[string]$Message){Write-HopassJson (Join-Path $Root 'update-status.json') @{state=$State;message=$Message;currentVersion=$current;availableVersion=$available;updatedAt=[DateTime]::UtcNow.ToString('o')};Add-Content -LiteralPath (Join-Path $Root 'logs\update.log') -Value ([DateTime]::Now.ToString('s')+' '+$State+' '+$Message) -Encoding UTF8}
function Restart-AfterUpdate {
 Remove-Item -LiteralPath (Join-Path $Root '.update-stop') -Force -ErrorAction SilentlyContinue
 if($Headless){Start-Hopass $Root}else{Start-Process -FilePath (Join-Path $Root 'HOPASSServer.exe') -WorkingDirectory $Root -WindowStyle Hidden|Out-Null}
 if(!(Wait-HopassHealth $Root 30)){throw '재시작 후 서버 상태 확인에 실패했습니다.'}
}
try{
 New-Item -ItemType Directory -Path (Join-Path $Root 'logs') -Force|Out-Null
 $oldPointer=Read-HopassJson (Join-Path $Root 'current.json');$current=[string]$oldPointer.version
 $cfg=Read-HopassJson (Join-Path $Root 'update-config.json');$uri=[uri][string]$cfg.manifest_url;Test-FeedUri $uri
 $job=Join-Path $Root ('updates\'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $job -Force|Out-Null
 Status 'checking' '업데이트 정보를 확인하고 있습니다.'
 $manifestPath=Join-Path $job 'manifest.json';Download-Hopass $uri $manifestPath 1048576;$manifest=Read-HopassJson $manifestPath
 $available=[string]$manifest.version
 if($manifest.product -ne 'HOPASS' -or $available -notmatch '^\d+\.\d+\.\d+$'){throw 'HOPASS 업데이트 정보가 아닙니다.'}
 if([version]$available -le [version]$current){Status 'completed' '현재 최신 버전입니다.';exit 0}
 if($CheckOnly){Status 'available' ('새 버전 '+$available+' · '+[string]$manifest.notes);exit 0}
 $download=New-Object uri($uri,[string]$manifest.url)
 if($download.Scheme -ne $uri.Scheme -or $download.Host -ne $uri.Host -or $download.Port -ne $uri.Port){throw '업데이트 주소가 배포 서버와 다릅니다.'}
 if([string]$manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw 'SHA-256 정보가 없습니다.'}
 $zip=Join-Path $job 'release.zip';Status 'downloading' '업데이트 다운로드 및 SHA-256 검증 중입니다.';Download-Hopass $download $zip
 $hash=(Hopass-Sha256 $zip);if($hash -ne ([string]$manifest.sha256).ToLowerInvariant()){throw 'SHA-256 검증 실패. 현재 서버를 유지합니다.'}
 $extract=Join-Path $job 'payload';Expand-HopassPackage $zip $extract
 foreach($file in @('version.json','HOPASS-Tray.ps1','Common.ps1','Update.ps1','server\server.mjs','server\bridge.mjs','server\init.mjs','server\admin.mjs','server\admin.html','integration\hugen-live.mjs','integration\hugen-direct.mjs','integration\HugenLogWriter.exe','integration\HugenLockInspector.exe','integration\Enable-HugenIntegration.ps1','integration\Disable-HugenIntegration.ps1')){if(!(Test-Path -LiteralPath (Join-Path $extract $file) -PathType Leaf)){throw ('필수 파일 누락: '+$file)}}
 $pv=Read-HopassJson (Join-Path $extract 'version.json');if($pv.product -ne 'HOPASS' -or $pv.version -ne $available){throw '패키지 버전 불일치'}
 foreach($protected in @('data','logs','runtime','current.json','update-config.json','server-config.json')){if(Test-Path -LiteralPath (Join-Path $extract $protected)){throw '설정/데이터를 포함한 업데이트 패키지는 허용하지 않습니다.'}}
 $destination=Join-Path $Root ('releases\'+$available)
 if(Test-Path -LiteralPath $destination){$marker=Join-Path $destination '.package-sha256';if(!(Test-Path -LiteralPath $marker) -or (Get-Content -LiteralPath $marker -Raw).Trim() -ne $hash){throw '기존 릴리스 경로와 충돌합니다.'}}
 else{New-Item -ItemType Directory -Path $destination -Force|Out-Null;Get-ChildItem -LiteralPath $extract -Force|Copy-Item -Destination $destination -Recurse -Force;$hash|Set-Content -LiteralPath (Join-Path $destination '.package-sha256') -Encoding ASCII}
 Status 'installing' '설정과 데이터를 보존하고 새 버전으로 전환합니다.'
 New-Item -ItemType File -Path (Join-Path $Root '.update-stop') -Force|Out-Null
 $stopped=$true;$end=[DateTime]::UtcNow.AddSeconds(20)
 while(Test-Path -LiteralPath (Join-Path $Root 'data\tray-heartbeat.json')){if([DateTime]::UtcNow -gt $end){throw '트레이 종료 확인에 실패했습니다. 현재 파일을 유지합니다.'};Start-Sleep -Milliseconds 300}
 Stop-Hopass $Root
 $backup=Join-Path $Root ('backups\'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6));New-Item -ItemType Directory -Path $backup -Force|Out-Null
 Copy-Item -LiteralPath (Join-Path $Root 'current.json') -Destination $backup
 Write-HopassJson (Join-Path $Root 'current.json') @{version=$available};$switched=$true
 Status 'restarting' '업데이트한 서버의 정상 응답을 확인합니다.'
 Restart-AfterUpdate
 if($env:HOPASS_TEST_FAIL_HEALTH -eq '1'){throw 'Injected post-switch health failure'}
 $serverCfg=Read-HopassJson (Join-Path $Root 'server-config.json');$h=Invoke-RestMethod ('http://127.0.0.1:'+$serverCfg.port+'/health') -TimeoutSec 3
 if($h.version -ne $available){throw '실행 중인 서버 버전이 일치하지 않습니다.'}
 $current=$available;$stopped=$false;Status 'completed' '업데이트 완료 · 서버 정상 응답을 확인했습니다.'
}catch{
 $reason=$_.Exception.Message;$recovery=''
 if($switched -or $stopped){try{
   # Ask any newly started tray to stop before switching back.
   New-Item -ItemType File -Path (Join-Path $Root '.update-stop') -Force|Out-Null
   $deadline=[DateTime]::UtcNow.AddSeconds(15)
   while((Test-Path -LiteralPath (Join-Path $Root 'data\tray-heartbeat.json')) -and [DateTime]::UtcNow -lt $deadline){Start-Sleep -Milliseconds 300}
   if(Test-Path -LiteralPath (Join-Path $Root 'data\tray-heartbeat.json')){throw '트레이 종료를 확인하지 못해 자동 복구를 중단했습니다.'}
   Stop-Hopass $Root;if($switched){Write-HopassJson (Join-Path $Root 'current.json') $oldPointer}
   Restart-AfterUpdate;$recovery=' 이전 버전 서버를 복구했습니다.'
  }catch{$recovery=' 자동 복구 확인 실패: '+$_.Exception.Message}
 }
 Status 'error' ($reason+$recovery);exit 1
}finally{
 Remove-Item -LiteralPath (Join-Path $Root '.update-stop') -Force -ErrorAction SilentlyContinue
 $mutex.ReleaseMutex();$mutex.Dispose()
}

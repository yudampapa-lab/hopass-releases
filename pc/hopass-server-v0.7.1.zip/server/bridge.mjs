import {readFileSync} from 'node:fs';
import {setDefaultResultOrder} from 'node:dns';
setDefaultResultOrder('ipv4first');
const base=(process.env.ONPASS_SERVER||'http://127.0.0.1:8787').replace(/\/$/,'');
const url=new URL(base);if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(url.hostname)))throw Error('Remote bridge connections require HTTPS');
const credentials=process.env.ONPASS_CREDENTIALS||new URL('./data/pilot-credentials.json',import.meta.url);
const token=JSON.parse(readFileSync(credentials)).bridgeToken;
const headers={authorization:`Bearer ${token}`,'content-type':'application/json'};
const liveUrl=process.env.HOPASS_LIVE_URL||'http://127.0.0.1:8790';
const liveSecretPath=process.env.HOPASS_LIVE_SECRET_FILE;
let liveSecret='';if(liveSecretPath)liveSecret=readFileSync(liveSecretPath,'utf8').trim();
console.log('HOPASS PC bridge started. Server mode decides simulation or live pilot handling.');
let stopped=false;process.on('SIGINT',()=>stopped=true);process.on('SIGTERM',()=>stopped=true);
let lastHeartbeat=0;
while(!stopped){let nextDelay=0;try{
 if(Date.now()-lastHeartbeat>=3000){let localStatus={hugenConnected:false,controllerConnected:false,lastEvent:liveSecret?'LOCAL_HEALTH_UNAVAILABLE':'LIVE_SECRET_MISSING'};if(liveSecret)try{const h=await fetch(liveUrl+'/health',{redirect:'error',signal:AbortSignal.timeout(1500)});if(h.ok){const value=await h.json();localStatus={hugenConnected:value.hugenConnected===true,controllerConnected:value.controllerConnected===true,lastEvent:typeof value.lastEvent==='string'?value.lastEvent.slice(0,180):''}}}catch{}
  const heartbeat=await fetch(base+'/v1/bridge/status',{method:'POST',headers,redirect:'error',body:JSON.stringify(localStatus),signal:AbortSignal.timeout(3000)});if(!heartbeat.ok)throw Error('bridge status HTTP '+heartbeat.status);lastHeartbeat=Date.now();
 }
 const res=await fetch(base+'/v1/bridge/commands?wait=4500',{headers,redirect:'error',signal:AbortSignal.timeout(6500)});if(!res.ok)throw Error('bridge HTTP '+res.status);
 const data=await res.json();if(!['simulation','live-pilot'].includes(data.mode))throw Error('unsupported mode');
 for(const cmd of data.commands){if(cmd.expiresAt<=Date.now())continue;
  let outcome={id:cmd.id,status:'SIMULATED'};
  if(cmd.mode==='live-pilot'){
   if(!liveSecret)outcome={id:cmd.id,status:'DEVICE_UNAVAILABLE',detail:'live secret missing'};
   else try{
    const live=await fetch(liveUrl+'/open',{method:'POST',headers:{authorization:`Bearer ${liveSecret}`,'content-type':'application/json'},redirect:'error',body:JSON.stringify(cmd),signal:AbortSignal.timeout(9000)});
    const value=await live.json();outcome={id:cmd.id,status:value.status,detail:value.detail||''};
    if(!live.ok&&!['DEVICE_REJECTED','DEVICE_UNAVAILABLE','OPENED_LOG_FAILED'].includes(value.status))outcome={id:cmd.id,status:'DEVICE_UNAVAILABLE',detail:'local integration HTTP '+live.status};
   }catch(e){outcome={id:cmd.id,status:'DEVICE_UNAVAILABLE',detail:e.message};}
  }
  const result=await fetch(base+'/v1/bridge/results',{method:'POST',headers,redirect:'error',body:JSON.stringify(outcome),signal:AbortSignal.timeout(5000)});
  if(!result.ok)throw Error('result HTTP '+result.status);console.log(outcome.status,cmd.id);
 }
}catch(e){console.error('Bridge connection:',e.message);nextDelay=1000;}await new Promise(r=>setTimeout(r,nextDelay));}

@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-KeeperFix.ps1"
if errorlevel 1 echo Installation failed. Please check the message above.
pause

﻿param([string]$Root=(Join-Path $env:LOCALAPPDATA 'HOPASSServer'),[switch]$NoRun)
$ErrorActionPreference='Stop'
$Root=[IO.Path]::GetFullPath($Root)
$backup=$null;$target=$null;$temporary=$null;$replaced=$false;$mutex=$null;$ownsMutex=$false
try {
    $version=[string](Get-Content -LiteralPath (Join-Path $Root 'current.json') -Raw | ConvertFrom-Json).version
    if($version -notmatch '^\d+\.\d+\.\d+$'){throw 'HOPASS 설치 버전을 확인할 수 없습니다.'}
    $target=Join-Path $Root ('releases\'+$version+'\integration\HugenKeeper.exe')
    $source=Join-Path $PSScriptRoot 'HugenKeeper.exe'
    if(!(Test-Path -LiteralPath $target -PathType Leaf)){throw 'HUGEN 자동 실행 기능이 포함된 HOPASS 서버에서 실행해 주세요.'}
    if(!(Test-Path -LiteralPath $source -PathType Leaf)){throw '압축을 모두 푼 뒤 Install.cmd를 실행해 주세요.'}
    $expected=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'HugenKeeper.sha256') -Raw).Trim()
    if($expected -notmatch '^[A-Fa-f0-9]{64}$' -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $expected){throw '패치 파일 검증에 실패했습니다. 다시 다운로드해 주세요.'}
    # Only stop this installation's recovery helpers, never Hugen.exe or the server.
    $prefix=([IO.Path]::GetFullPath((Join-Path $Root 'releases'))).TrimEnd('\')+'\'
    foreach($process in @(Get-Process -Name HugenKeeper -ErrorAction SilentlyContinue)){
        $path=$null
        try{$path=[IO.Path]::GetFullPath($process.Path)}catch{}
        if($path -and $path.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($path) -eq 'HugenKeeper.exe'){
            if($process.MainWindowHandle -ne 0){throw 'HUGEN 자동 실행 설정 창을 닫은 뒤 다시 실행해 주세요.'}
            $process.Kill();if(!$process.WaitForExit(5000)){throw '기존 복구 프로그램 종료를 확인하지 못했습니다.'}
        }
    }
    $mutex=New-Object Threading.Mutex($false,'HOPASS.HugenKeeper.CurrentUser')
    try{$ownsMutex=$mutex.WaitOne(5000)}catch [Threading.AbandonedMutexException]{$ownsMutex=$true}
    if(!$ownsMutex){throw '복구 프로그램이 사용 중입니다. 잠시 후 다시 실행해 주세요.'}
    $backupDirectory=Join-Path $Root ('backups\keeper-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
    New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
    $backup=Join-Path $backupDirectory 'HugenKeeper.exe'
    Copy-Item -LiteralPath $target -Destination $backup
    $temporary=$target+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    Copy-Item -LiteralPath $source -Destination $temporary
    [IO.File]::Replace($temporary,$target,[Management.Automation.Language.NullString]::Value)
    $replaced=$true
    if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $expected){throw '설치 파일 확인에 실패했습니다.'}
    Write-Host 'HUGEN 자동 실행 패치를 설치했습니다. 기존 계정과 서버 설정은 유지됩니다.'
    Write-Host ('백업: '+$backupDirectory)
} catch {
    if($replaced -and $backup -and (Test-Path -LiteralPath $backup)){Copy-Item -LiteralPath $backup -Destination $target -Force}
    Write-Error $_
    exit 1
} finally {
    if($temporary -and (Test-Path -LiteralPath $temporary)){Remove-Item -LiteralPath $temporary -Force}
    if($ownsMutex){$mutex.ReleaseMutex()}
    if($mutex){$mutex.Dispose()}
}
if(!$NoRun){
    Start-Process -FilePath $target -ArgumentList ('--root "'+$Root.TrimEnd('\')+'"') -WindowStyle Hidden | Out-Null
    Write-Host '자동 복구를 시작했습니다. 수집 상태는 HOPASSServer\logs\hugen-keeper.log에서 확인할 수 있습니다.'
}

import {createReadStream} from 'node:fs';
import {dirname,join} from 'node:path';
import {createInterface} from 'node:readline';

export async function localRetentionPreview(configPath,now=Date.now()){
 const result={totalLogEntries:0,candidateLogEntries:0,protectedPending:0,invalidLines:0,truncated:false,available:true};
 const stream=createReadStream(join(dirname(configPath),'events.jsonl'),{encoding:'utf8'});
 const lines=createInterface({input:stream,crlfDelay:Infinity});
 try{for await(const line of lines){
  if(!line.trim())continue;
  if(result.totalLogEntries>=200000){result.truncated=true;break}
  result.totalLogEntries++;
  let value;try{value=JSON.parse(line)}catch{result.invalidLines++;continue}
  const r=value.request;if(!r||typeof r!=='object'){result.invalidLines++;continue}
  if(r.status==='PENDING'){result.protectedPending++;continue}
  if(!['OPENED_NO_RECORD','OPENED_RECORDED','OPENED_LOG_FAILED','DEVICE_REJECTED','DEVICE_UNAVAILABLE','EXPIRED'].includes(r.status))continue;
  const at=r.completedAt??value.at;
  if(typeof at!=='number'||!Number.isFinite(at)||at<=0){result.invalidLines++;continue}
  if(at<=now-90*86400000)result.candidateLogEntries++;
 }}catch(e){if(e.code==='ENOENT')result.available=false;else throw e}
 finally{lines.close();stream.destroy()}
 return result;
}

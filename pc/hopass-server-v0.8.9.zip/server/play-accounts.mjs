import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import {dirname,join} from 'node:path';

export function normalizePlayEmail(value){
 if(typeof value!=='string')throw Object.assign(Error('invalid_play_email'),{code:400});
 const email=value.trim().toLowerCase();
 if(email&&(email.length>254||! /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(email)||email.startsWith('.')||email.includes('..')||email.split('@')[0].endsWith('.')||email.split('@')[0].length>64))throw Object.assign(Error('invalid_play_email'),{code:400});
 return email;
}
export function playAccountStore(configPath){
 const path=join(dirname(configPath),'play-accounts.json');
 function read(){
  let value;try{value=JSON.parse(readFileSync(path,'utf8'))}catch(e){if(e.code==='ENOENT')return [];throw e}
  if(value.version!==1||!Array.isArray(value.accounts)||value.accounts.some(a=>!a||typeof a.id!=='string'||typeof a.email!=='string'))throw Error('invalid_play_accounts_file');
  return value.accounts;
 }
 return {
  decorate(config){const accounts=new Map(read().map(a=>[a.id,a.email]));return {...config,employees:config.employees.map(e=>({...e,playEmail:accounts.get(e.id)||''}))}},
  set(id,value){const email=normalizePlayEmail(value),accounts=read().filter(a=>a.id!==id);if(email)accounts.push({id,email});const temp=path+'.tmp';writeFileSync(temp,JSON.stringify({version:1,accounts},null,2),{mode:0o600});renameSync(temp,path);return email;},
  remove(id){const accounts=read();if(accounts.some(a=>a.id===id))this.set(id,'');}
 };
}
